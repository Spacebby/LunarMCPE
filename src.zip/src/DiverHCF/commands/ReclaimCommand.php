<?php

namespace DiverHCF\commands;

use DiverHCF\Loader;

use DiverHCF\reclaim\ReclaimManager;
use DiverHCF\utils\Time;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

use libs\muqsit\invmenu\InvMenu;

class ReclaimCommand extends PluginCommand {
	
	/**
	 * ReclaimCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("reclaim", Loader::getInstance());
		
		parent::setDescription("Claim your daily rewards");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!empty($args[0]) && $sender->hasPermission("reclaim.command.use")){
			switch($args[0]){
				case "create":
					if(!$sender->isOp()){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					if(empty($args[1])){
						$sender->sendMessage(TE::RED."Argument #1 is not valid for command syntax");
						return;
					}
					if(ReclaimManager::isReclaim($args[1])){
						$sender->sendMessage(str_replace(["{rankName}"], [$args[1]], Loader::getConfiguration("messages")->get("reclaim_alredy_exists")));
						return;
					}
					$reclaimData = [
						"name" => $args[1],
						"contents" => $sender->getInventory()->getContents(),
					];
					ReclaimManager::createReclaim($reclaimData);
					$sender->sendMessage(str_replace(["{rankName}"], [$args[1]], Loader::getConfiguration("messages")->get("reclaim_create_correctly")));
				break;
				case "delete":
					if(!$sender->isOp()){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					if(empty($args[1])){
						$sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} [string: rankName]");
						return;
					}
					if(!ReclaimManager::isReclaim($args[1])){
						$sender->sendMessage(str_replace(["{rankName}"], [$args[1]], Loader::getConfiguration("messages")->get("reclaim_not_exists")));
						return;
					}
					ReclaimManager::removeReclaim($args[1]);
					$sender->sendMessage(str_replace(["{rankName}"], [$args[1]], Loader::getConfiguration("messages")->get("reclaim_delete_correctly")));
				break;
				case "edit":
					if(!$sender->isOp()){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					if(empty($args[1])||empty($args[2])){
						$sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} [string: rankName] [string: items]");
						return;
					}
					if(!ReclaimManager::isReclaim($args[1])){
						$sender->sendMessage(str_replace(["{rankName}"], [$args[1]], Loader::getConfiguration("messages")->get("reclaim_not_exists")));
						return;
					}
					switch($args[2]){
						case "items":
							$reclaim = ReclaimManager::getReclaim($args[1]);
							$reclaim->setItems($sender->getInventory()->getContents());
							$sender->sendMessage(str_replace(["{rankName}"], [$reclaim->getName()], Loader::getConfiguration("messages")->get("reclaim_edit_items_correctly")));
						break;
					}
				break;
				case "list":
					if(!$sender->isOp()){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					$sender->sendMessage(TE::GREEN.ReclaimManager::getReclaimsWithString());
				break;
				case "rewards":
					if(!$sender->isOp()){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					if(empty($args[1])){
						$sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} [string: rankName]");
						return;
					}
					if(!ReclaimManager::isReclaim($args[1])){
						$sender->sendMessage(str_replace(["{rankName}"], [$args[1]], Loader::getConfiguration("messages")->get("reclaim_not_exists")));
						return;
					}
					$reclaim = ReclaimManager::getReclaim($args[1]);
					$menu = InvMenu::create(InvMenu::TYPE_CHEST);
					$menu->getInventory()->setContents($reclaim->getItems());
					$menu->send($sender);
				break;
				case "help":
				case "?":
					if(!$sender->isOp()){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					$sender->sendMessage(
						TE::YELLOW."/{$label} create [string: rankName] ".TE::GRAY."(To create a new rank reclaim)"."\n".
						TE::YELLOW."/{$label} delete [string: rankName] ".TE::GRAY."(To remove a rank reclaim from the list)"."\n".
						TE::YELLOW."/{$label} edit [string: rankName] [string: args] ".TE::GRAY."(To edit the items of the reclaim)"."\n".
						TE::YELLOW."/{$label} list ".TE::GRAY."(See list of reclaims create)"."\n".
						TE::YELLOW."/{$label} rewards [string: rankName] ".TE::GRAY."(See rewards of ranks)"
					);
				break;
			}
		}else{
			if($sender->getTimeReclaimRemaining() < time()){
				ReclaimManager::giveReclaim($sender);
			}else{
				$sender->sendMessage(str_replace(["{time}"], [Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
    }
}

?>