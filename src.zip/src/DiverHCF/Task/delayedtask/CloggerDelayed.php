<?php

namespace DiverHCF\Task\delayedtask;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\entity\Entity;
use pocketmine\item\ItemIds;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class CloggerDelayed extends Task {
	
	/** @var Player */
	protected $player;
	
	/**
	 * StormBreakerDelayed Constructor.
	 * @param Player $player
	 */
	public function __construct(Player $player){
		$this->player = $player;
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun(Int $currentTick) : void {
		$player = $this->player;
		if(!$player->isOnline()){
            Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
            return;		
			}	 
				$player->addClogger();
                $player->addClogger();
			}	 
		}
    	Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
    }
}

?>