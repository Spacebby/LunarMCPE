<?php

namespace DiverHCF\listeners;

use DiverHCF\{Loader, Factions};
use pocketmine\level\particle\HugeExplodeSeedParticle;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\scheduler\ClosureTask;
use DiverHCF\player\Player;

use DiverHCF\utils\Time;
use DiverHCF\packages\PackageManager;

use DiverHCF\Task\EnderPearlTask;

use DiverHCF\entities\ZombieBard;

use DiverHCF\Task\specials\{AntiTrapperTask, SpecialItemTask, NinjaShearTask, LoggerBaitTask, StormBreakerTask, TimestoneTask, RagebrickTask, BerserkTask, MedkitTask, EnergyTask, StrengthTask, ResistanceTask, FireworkTask, AntiPearlTask, RageballTask, PbardTask, FocusmodeTask};
use DiverHCF\Task\delayedtask\{StormBreakerDelayed, NinjaShearDelayed};

use DiverHCF\item\specials\{Custom, CustomProjectileItem, StormBreaker, EffectDisabler, AntiTrapper, NinjaShear, Strength, Rageball, Resistance, Invisibility, Timestone, Firework, PrePearl, PartnerPackages, LoggerBait, PBackstab, Ragebrick, Starvation, Berserk, Medkit, Cactus, Energy, AntiPearl, Pbard, Focusmode, ZombieBardItem, Clogger, CloggerFill};

use pocketmine\utils\TextFormat as TE;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\item\{Item, ItemFactory, ItemIds};
use pocketmine\entity\{Effect, EffectInstance, Entity, Villager};
use pocketmine\block\{Fence, FenceGate, Fire};

use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent, ProjectileHitEvent, ProjectileHitEntityEvent};
use pocketmine\event\player\PlayerInteractEvent;

class SpecialItems implements Listener
{

    /**
     * SpecialItems Constructor.
     */
    public function __construct()
    {

    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function onEntityDamageEvent(EntityDamageEvent $event): void
    {
        $player = $event->getEntity();
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($player instanceof Player && $damager instanceof Player) {
                if ($event->getCause() === EntityDamageEvent::CAUSE_ENTITY_ATTACK) {
                    $item = $damager->getInventory()->getItemInHand();
                    if($item instanceof Custom){
                        if($player->isSpecialItem()){
                            $player->sendTip(str_replace(["{time}"], [Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("SpecialItem_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                    }
                    
                    if (!Factions::isSpawnRegion($damager) && $item instanceof StormBreaker && $item->getNamedTagEntry(StormBreaker::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isStormBreaker()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getStormBreakerTime())], Loader::getConfiguration("messages")->get("stormbreaker_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("stormbreaker_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet
                        Loader::getInstance()->getScheduler()->scheduleDelayedTask(new StormBreakerDelayed($player), 40);

                        $item->reduceUses($damager);
                        $damager->setStormBreaker(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new StormBreakerTask($damager), 20);
                    }
                    
                    if (!Factions::isSpawnRegion($damager) && $item instanceof Starvation && $item->getNamedTagEntry(Starvation::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isSpecialItem()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $player->setFood(0);
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("starvation_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet

                        $damager->getInventory()->setItemInHand($damager->getInventory()->getItemInHand()->setCount($damager->getInventory()->getItemInHand()->getCount() - 1));
                        $damager->setSpecialItem(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($damager), 20);
                    }
                    
                    if (!Factions::isSpawnRegion($damager) && $item instanceof Clogger && $item->getNamedTagEntry(Clogger::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isSpecialItem()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $cloggerfill = new CloggerFill();
                        
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        $player->getInventory()->addItem($cloggerfill);
                        
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("clogger_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet

                        $damager->getInventory()->setItemInHand($damager->getInventory()->getItemInHand()->setCount($damager->getInventory()->getItemInHand()->getCount() - 1));
                        $damager->setSpecialItem(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($damager), 20);
                    }
                    
                    if (!Factions::isSpawnRegion($damager) && $item instanceof PBackstab && $item->getNamedTagEntry(PBackstab::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isSpecialItem()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $player->setHealth($player->getHealth() - 4);
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("pbackstab_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet

                        $damager->getInventory()->setItemInHand($damager->getInventory()->getItemInHand()->setCount($damager->getInventory()->getItemInHand()->getCount() - 1));
                        $damager->setSpecialItem(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($damager), 20);
                    }
                    
                     if (!Factions::isSpawnRegion($damager) && $item instanceof AntiPearl && $item->getNamedTagEntry(AntiPearl::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isSpecialItem()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $player->setEnderPearl(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new EnderPearlTask($player), 20);
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("antipearl_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet

                        $damager->getInventory()->setItemInHand($damager->getInventory()->getItemInHand()->setCount($damager->getInventory()->getItemInHand()->getCount() - 1));
                        $damager->setSpecialItem(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($damager), 20);
                    }
                    
                    if (!Factions::isSpawnRegion($damager) && $item instanceof EffectDisabler && $item->getNamedTagEntry(EffectDisabler::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isSpecialItem()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $player->removeEffect(Effect::STRENGTH);
                        $player->removeEffect(Effect::RESISTANCE);
                        $player->removeEffect(Effect::REGENERATION);
                        $player->removeEffect(Effect::SPEED);
                        
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("effectdisabler_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet

                        $damager->getInventory()->setItemInHand($damager->getInventory()->getItemInHand()->setCount($damager->getInventory()->getItemInHand()->getCount() - 1));
                        $damager->setSpecialItem(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($damager), 20);
                    }

                    if (!Factions::isSpawnRegion($damager) && $item instanceof AntiTrapper && $item->getNamedTagEntry(AntiTrapper::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isAntiTrapper()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_cooldown")));
                            $event->setCancelled(true);
                            return;
                        }
                        $damager->getInventory()->setItemInHand($damager->getInventory()->getItemInHand()->setCount($damager->getInventory()->getItemInHand()->getCount() - 1));
	                    $damager->setAntiTrapper(true);
                        //here we place the time for which the player cannot place blocks
                        $player->setAntiTrapperTarget(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new AntiTrapperTask($damager, $player), 20);
                    } 
                }
            }
        }
    }
    
     /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function onBlockBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player->isAntiTrapperTarget()) {
            $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
            $event->setCancelled(true);
        }
    }

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function onBlockPlace(BlockPlaceEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player->isAntiTrapperTarget()) {
            $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
            $event->setCancelled(true);
        }
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $item = $event->getItem();
        if ($player instanceof Player) {
            if ($player->isAntiTrapperTarget()) {
                if ($block instanceof Fence || $block instanceof FenceGate) {
                    $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
                    $event->setCancelled(true);
                }
            }
            if ($item instanceof Strength && $item->getNamedTagEntry(Strength::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
            if($item instanceof ZombieBardItem && $item->getNamedTagEntry(ZombieBardItem::CUSTOM_ITEM) instanceof CompoundTag){
            if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
                if($player->isSpecialItem()){
                  $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                    $event->setCancelled(true);
                    return;
                }
                $nbt = Entity::createBaseNBT($block->add(0, 1, 0));
				$ent = new ZombieBard($player->getLevel(), $nbt, $player->getName());
				$ent->spawnToAll();
			
				$item->setCount($item->getCount() - 1);
                $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                $player->setSpecialItem(true);
                
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
            if ($item instanceof LoggerBait && $item->getNamedTagEntry(LoggerBait::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isLoggerBait()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getLoggerBaitTime())], Loader::getConfiguration("messages")->get("loggerbait_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $nbt = Entity::createBaseNBT(new Vector3((float)$player->getX(), (float)$player->getY(), (float)$player->getZ()));
                    $human = new Villager($player->getLevel(), $nbt);
                    $human->setNameTagVisible(true);
                    $human->setNameTagAlwaysVisible(true);
                    $human->yaw = $player->getYaw();
                    $human->pitch = $player->getPitch();
                    $human->setNameTag(TE::GRAY . "(Combat-Logger) " . TE::RED . $player->getName() . TE::GRAY);
                    $human->spawnToAll();
                    $player->setLoggerBait(true);
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setLoggerBait(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new LoggerBaitTask($player), 20);
                }
            }
             if ($item instanceof Cactus && $item->getNamedTagEntry(Cactus::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 4, 3)); 
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 3 * 4, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 16, 2)); 
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 10, 2));


                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 4, 3));
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 16, 2)); 
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 10, 2));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
            if ($item instanceof Timestone && $item->getNamedTagEntry(Timestone::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isTimestone()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getTimestoneTime())], Loader::getConfiguration("messages")->get("timestone_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->setStrength(false);
                    
                    
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setTimestone(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new TimestoneTask($player), 20);
                }
            }
            if ($item instanceof RageBrick && $item->getNamedTagEntry(RageBrick::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 10, 1));


                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new RagebrickTask($player), 20);
                }
            }
             if ($item instanceof Berserk && $item->getNamedTagEntry(Berserk::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 15 * 10, 2));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
             if ($item instanceof Medkit && $item->getNamedTagEntry(Medkit::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 15 * 10, 1));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 15 * 10, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 15 * 10, 3));    

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
             if ($item instanceof Energy && $item->getNamedTagEntry(Energy::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 10, 2));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
             if ($item instanceof Pbard && $item->getNamedTagEntry(Pbard::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 15 * 10, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 15 * 10, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));    

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
             if ($item instanceof Resistance && $item->getNamedTagEntry(Resistance::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 15 * 10, 2));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 15 * 10, 2));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
            
             if ($item instanceof Rageball && $item->getNamedTagEntry(Rageball::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 17 * 10, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 17 * 10, 1));
                    
                    $source = (new Vector3($player->x, $player->y, $player->z))->floor();
                    $player->getLevel()->addParticle(new HugeExplodeSeedParticle($source));
                    $player->getLevel()->addSound(new BlazeShootSound($source));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 17 * 10, 2));
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 17 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }

            if ($item instanceof Invisibility && $item->getNamedTagEntry(Invisibility::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 20 * 60, 1));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayer($value);
                            if ($online instanceof Player && $online->distanceSquared($player) < 30) {
                                $online->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 20 * 60, 0));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
            if($item instanceof NinjaShear && $item->getNamedTagEntry(NinjaShear::CUSTOM_ITEM) instanceof CompoundTag){
            if($player->isNinjaShear()){
                $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getNinjaShearTime())], Loader::getConfiguration("messages")->get("ninjashear_cooldown")));
                $event->setCancelled(true);
                return;
            }
            if(empty($player->getNinjaShearPosition())){
                $player->sendTip(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("ninjashear_have_no_hit_registered")));
                return;
            }
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("ninjashear_was_used_correctly")));
            
            # This task runs after a few seconds, to teleport the player to the saved position
            Loader::getInstance()->getScheduler()->scheduleDelayedTask(new NinjaShearDelayed($player, $player->getNinjaShearPosition()), 20);
            
            $item->reduceUses($player);
            $player->setNinjaShear(true);
            $player->setNinjaShearTime(Loader::getDefaultConfig("Cooldowns")["NinjaShear"]);
            Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new NinjaShearTask($player), 20);

            
        }
            if ($item instanceof Firework && $item->getNamedTagEntry(Firework::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isFirework()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getFireworkTime())], Loader::getConfiguration("messages")->get("firework_cooldown")));
                        $event->setCancelled(true);
                        return;
                    }
                    $player->knockBack($player, 0, $player->getDirectionVector()->x, $player->getDirectionVector()->z, 2.1);

                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    $player->setFirework(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new FireworkTask($player), 20);
                    return;
                }
            }
        }
       
        if($item instanceof PartnerPackages && $item->getNamedTagEntry(PartnerPackages::CUSTOM_ITEM) instanceof CompoundTag){
            if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
                $package = PackageManager::getPackage();
                if(empty($package)) return;{

                foreach(PackageManager::getRewards() as $item){
                    if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
                        return;
                    }
                    $player->getInventory()->addItem($item);
                    $player->getInventory()->setItemInHand($player->getInventory()->getItemInHand()->setCount($player->getInventory()->getItemInHand()->getCount() - 1));
                    $player->sendMessage(str_replace(["&", "{itemName}"], ["§", $item->getName()], Loader::getConfiguration("messages")->get("package_give_reward_correctly")));

                    $source = (new Vector3($player->x, $player->y, $player->z))->floor();
                    $player->getLevel()->addParticle(new HugeExplodeSeedParticle($source));
                    $player->getLevel()->addSound(new BlazeShootSound($source));
                    }
                }
            }
        }
    }
}

?>