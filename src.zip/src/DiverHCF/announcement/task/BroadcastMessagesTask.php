<?php



declare(strict_types = 1);



namespace DiverHCF\announcement\task;



use DiverHCF\Loader;

use DiverHCF\translation\Translation;

use DiverHCF\translation\TranslationException;

use pocketmine\scheduler\Task;

use pocketmine\utils\TextFormat;



class BroadcastMessagesTask extends Task {



    /** @var Cryptic */

    private $core;



    /**

     * BroadcastMessagesTask constructor.

     *

     * @param Cryptic $core

     */

    public function __construct(Loader $core) {

        $this->core = $core;

    }



    /**

     * @param int $currentTick

     *

     * @throws TranslationException

     */

   public function onRun(int $currentTick) {

        $message = $this->core->getAnnouncementManager()->getNextMessage();

        $this->core->getServer()->broadcastMessage(Translation::getMessage("broadcastMessage", [

            "message" => TextFormat::LIGHT_PURPLE . $message

        ]));

    }

}