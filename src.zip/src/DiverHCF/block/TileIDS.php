<?php

namespace DiverHCF\block;

interface TileIDS{
    
 const DISPENSER = "Dispenser";
}