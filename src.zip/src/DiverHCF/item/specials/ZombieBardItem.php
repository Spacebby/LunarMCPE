<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};

class ZombieBardItem extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * ZombieBard Constructor.
	 */
	public function __construct(){
		parent::__construct(self::SPAWN_EGG, "§l§9Portable Bard", [TE::RESET.TE::GRAY."Use this to summon your own Bard"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1)));
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>