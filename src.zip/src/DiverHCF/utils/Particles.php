<?php

namespace DiverHCF\utils;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\math\Vector3;

use pocketmine\level\particle\FloatingTextParticle;

use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;

class Particles {


    /**
	 * @param Player $player
     * @param Array $floatingParticles
     * @return void
	 */
	public static function decode(Player $player, Array $floatingParticles = []) : void {
		if(empty($floatingParticles)){
            Loader::getInstance()->getLogger()->error("The parameter must have content, it cannot be empty");
            return;
        }
        foreach(array_values($floatingParticles) as $particle){
            if($particle instanceof FloatingTextParticle){
                foreach($particle->encode() as $decode){
                    $particle->setInvisible(false);
                    $player->dataPacket($decode);
                }
            }
        }
    }

    /**
	 * @param Player $player
     * @param Array $floatingParticles
     * @return void
	 */
	public static function encode(Player $player, Array $floatingParticles = []) : void {
		if(empty($floatingParticles)){
            Loader::getInstance()->getLogger()->error("The parameter must have content, it cannot be empty");
            return;
        }
        foreach(array_values($floatingParticles) as $particle){
            if($particle instanceof FloatingTextParticle){
                foreach($particle->encode() as $decode){
                    $particle->setInvisible(true);
                    $player->dataPacket($decode);
                }
            }
        }
    }

    /**
     * @param Vector3 $position
     * @param String $type
     * @return void
     */
    public static function spawn(Player $player, Vector3 $position, String $type) : void {
        $pk = new SpawnParticleEffectPacket();
        $pk->particleName = $type;
        $pk->position = $position;
        $player->sendDataPacket($pk);
    }
}

?>