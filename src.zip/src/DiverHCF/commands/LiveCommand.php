<?php

namespace DiverHCF\commands;

use DiverHCF\Loader;

use pocketmine\command\{CommandSender, PluginCommand};

use pocketmine\utils\TextFormat as TE;

class LiveCommand extends PluginCommand{

    public function __construct(){

        parent::__construct("live", Loader::getInstance());

        

        parent::setAliases(["stream"]);

        parent::setPermission("live.command.use");

        parent::setDescription("an exclusive command for streamers");

    }

    public function execute(CommandSender $sender, String $label, Array $args) : void {

        if(!$sender->hasPermission("live.command.use")){

            $sender->sendMessage(TE::RED."You have not permissions to use this command");

            return;

        }

        if(empty($args[0])) {

                $sender->sendMessage(TE::RED . "Use: /{$label} <message>");

                return;

        }

        $alert = implode(" ", $args);

        Loader::getInstance()->getServer()->broadcastMessage("§5---------------------------------------------");

		Loader::getInstance()->getServer()->broadcastMessage("§l§d".$sender->getName()." §l§eEsta En Directo Ven:"."\n §d".$alert);

		Loader::getInstance()->getServer()->broadcastMessage("§5---------------------------------------------");

    }

}