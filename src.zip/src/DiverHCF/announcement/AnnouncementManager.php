<?php

declare(strict_types = 1);

namespace DiverHCF\announcement;

use DiverHCF\announcement\task\BroadcastMessagesTask;

use DiverHCF\announcement\task\RestartTask;

use DiverHCF\Loader;

class AnnouncementManager {

    /** @var Cryptic */

    private $core;

    /** @var string[] */

    private $messages;

    /** @var int */

    private $currentId = 0;

    /**

     * AnnouncementManager constructor.

     *

     * @param Cryptic $core

     */

    public function __construct(Loader $core) {

        $this->core = $core;

        $this->init();

        $core->getScheduler()->scheduleRepeatingTask(new BroadcastMessagesTask($core), 1000);

    }

      public function init(): void {

       $this->messages = [

            "\n§l§3[§6HCF§3] §l§2» §r §l§7Quieres comprar rango? en Nuestro discord puedes comprar alguno",

            "\n §l§3[§6HCF§4] §l§2»  §c§lADVERTENCIA §r§4GLITCHING §r§7es baneable no uses glitch §l§o §r§7seras baneado§r\n",

            "\n §l§3[§6HCF§4] §l§2» §r §l§c§lHACKING §r§7resultara en un ban inmediatamente no uses §l§ccheat§r\n",

            "\n§l§3[§6HCF§3] §l§2» §r §l§7Chatea con nuestra comunidad, informa de problemas y visualiza actualizaciones en nuestro servidor de Discord. ¡Únete a nuestro servidor discord ahora! §bDiscord.gg/puUMc4Z5GR.§r\n",

            "\n §l§3[§6HCF§3]  §l§2» §r §l§7¿Necesita saber la IP y el PUERTO del servidor?  §l§bIP: PenguinHcf.net §r §7| §bPORT: 19132§r§7§r\n",

       ];

    }

    /**

     * @return string

     */

    public function getNextMessage(): string {

        if(isset($this->messages[$this->currentId])) {

            $message = $this->messages[$this->currentId];

            $this->currentId++;

            return $message;

        }

        $this->currentId = 0;

        return $this->messages[$this->currentId];

    }

    /**

     * @return RestartTask

     */

    public function getRestarter(): RestartTask {

        return $this->restarter;

    }

}

