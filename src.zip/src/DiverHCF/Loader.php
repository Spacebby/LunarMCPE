<?php

namespace DiverHCF;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use DiverHCF\translation\TranslationException;
use DiverHCF\announcement\AnnouncementManager;

use DiverHCF\provider\{
    SQLite3Provider, YamlProvider, MysqlProvider,
};
use DiverHCF\player\{
    Player,
};
use DiverHCF\API\{
    Scoreboards,
};
use DiverHCF\Task\{
	BardTask, ArcherTask, MageTask, 
};
use DiverHCF\Task\event\{
	FactionTask,
};
use DiverHCF\block\{
    Blocks,
};
use DiverHCF\listeners\{
	Listeners,
};
use DiverHCF\commands\{
    Commands,
};
use DiverHCF\item\{
    Items,
};
use DiverHCF\vkit\{
    vKits,
};
use DiverHCF\entities\{
    Entitys,
};
use DiverHCF\enchantments\{
    Enchantments,
};
use DiverHCF\utils\{Data, Extensions};
use libs\muqsit\invmenu\InvMenuHandler;

class Loader extends PluginBase {
    
     /** @var AnnouncementManager */

    private $announcementManager;
    
    /** @var Loader */
    protected static $instance;
    
    /** @var Array[] */
    public static $appleenchanted = [], $rogue = [];
    
    /** @var Array[] */
	public $permission = [];
    
    /**
     * @return void
     */
    public function onLoad() : void {
        self::$instance = $this;
    }
    
    /**
     * @return void
     */
    public function onEnable(): void
    {
        
        $this->getLogger()->info("==========================================");
        MysqlProvider::connect();
        SQLite3Provider::connect();

        Listeners::init();
        Commands::init();
        Items::init();
        Blocks::init();
        Entitys::init();
        Enchantments::init();
        
        YamlProvider::init();
        
        Factions::init();
        InvMenuHandler::register($this);
        

        $this->getScheduler()->scheduleRepeatingTask(new BardTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new ArcherTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new MageTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new FactionTask(), 5 * 60 * 40);
        $this->announcementManager = new AnnouncementManager($this);
         $this->getLogger()->info("New providers registered -> (3)");
         $this->getLogger()->info("==========================================");
         $this->getLogger()->info("This Core is Only Allowed For Eternity PvP HCF");
         $this->getLogger()->info("Author: Lov3iyBBY and z4iipic");
         $this->getLogger()->info("==========================================");
    }
    
    /**
     * @return void
     */
    public function onDisable() : void {
        SQLite3Provider::disconnect();
        MysqlProvider::disconnect();

        YamlProvider::save();
    }

    /**
     * @return Loader
     */
    public static function getInstance() : Loader {
        return self::$instance;
    }

    /**
     * @return SQLite3Provider
     */
    public static function getProvider() : SQLite3Provider {
        return new SQLite3Provider();
    }

    /**
     * @return Scoreboards
     */
	public static function getScoreboard() : Scoreboards {
		return new Scoreboards();
    }

    /**
     * @param String $configuration
     */
    public static function getDefaultConfig($configuration){
        return self::getInstance()->getConfig()->get($configuration);
    }
    
    /**
     * @param String $configuration
     */
    public static function getConfiguration($configuration){
    	return new Config(self::getInstance()->getDataFolder()."{$configuration}.yml", Config::YAML);
    }
    public function getAnnouncementManager(): AnnouncementManager {

        return $this->announcementManager;

    /**
     * @param Player $player
     */
       }
    public function getPermission(Player $player){
        if(!isset($this->permission[$player->getName()])){
            $this->permission[$player->getName()] = $player->addAttachment($this);
        }
        return $this->permission[$player->getName()];
    }
}

?>