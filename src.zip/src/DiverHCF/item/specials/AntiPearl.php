<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\CompoundTag;

class AntiPearl extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	const USES_LEFT = "Uses left";
	
	/**
	 * StormBreaker Constructor.
	 * @param Int $usesLeft
	 */
	public function __construct(Int $usesLeft = 1){
		parent::__construct(self::ENDER_EYE, TE::BLUE.TE::BOLD."Anti Pearl", [TE::RESET.TE::GRAY."Can put damager on ender pearl cooldown"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1)));
		$this->getNamedTagEntry(self::CUSTOM_ITEM)->setInt(self::USES_LEFT, $usesLeft);
	}
	
	/**
	 * @param Player $player
	 * @return void
	 */
	public function reduceUses(Player $player) : void {
		$nbt = $this->getNamedTagEntry(self::CUSTOM_ITEM)->getInt(self::USES_LEFT);
		if($nbt > 0){
			$nbt--;
			if($nbt === 0){
				$player->getInventory()->setItemInHand(self::get(self::AIR));
			}else{
				$this->getNamedTagEntry(self::CUSTOM_ITEM)->setInt(self::USES_LEFT, $nbt);
				$this->setLore([TE::RESET."\n".TE::GRAY."When you hit a player with this".TE::GRAY."\n".TE::GRAY."they may not blockup for 15 seconds".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in".TE::RED." Partner Packages"."\n\n".TE::YELLOW."Uses Left: ".TE::GOLD.$nbt]);
				$player->getInventory()->setItemInHand($this);
			}
		}
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>