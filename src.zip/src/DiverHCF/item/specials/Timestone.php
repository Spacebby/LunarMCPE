<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\CompoundTag;

class Timestone extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Strength Constructor.
	 */
	public function __construct(){
		parent::__construct(self::HEART_OF_THE_SEA,  TE::BLUE.TE::BOLD."Ablity Reset", [TE::RESET.TE::GRAY."Use this to reset ur Partner Item Cooldown"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1)));
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>