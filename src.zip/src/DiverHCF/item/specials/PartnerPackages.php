<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;

use DiverHCF\packages\PackageManager;

use pocketmine\utils\TextFormat as TE;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\CompoundTag;


use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\ItemFactory;

class PartnerPackages extends Custom {

    const CUSTOM_ITEM = "CustomItem";

    /**
	 * PartnerPackages Constructor.
	 */
	public function __construct(){
		parent::__construct(self::ENDER_CHEST, TE::BOLD.TE::BLUE."Partner Packages", ["\n".TE::GRAY."Open this Package to recive Special items that"."\n"."give's you a advantage In any pvp"."\n\n".TE::AQUA."Available for purchase at".TE::DARK_AQUA."discord.gg/elementalpvp"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1)));

	}
}

?>