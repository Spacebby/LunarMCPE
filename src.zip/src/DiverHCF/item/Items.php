<?php

namespace DiverHCF\item;

use DiverHCF\Loader;
use pocketmine\utils\TextFormat as TE;
use DiverHCF\item\specials\{Firework,
    SecondChance,
    RemoveEffect,
    StormBreaker,
    AntiTrapper,
    NinjaShear,   
    ZombieBardItem,                        
    EggPorts,
    Focusmode,    
    PBackstab,                        
    Strength,
    Clogger,                        
    CloggerFill,                  
    Resistance,
    Invisibility,
    Rageball,                        
    Pbard, 
    Cactus,                        
    LoggerBait,
    RageBrick,
    EffectDisabler,                        
    RareBrick,  
    Timestone,                        
    Berserk,
    Starvation,                        
    Energy,
    AntiPearl,
    Medkit,                        
    PartnerPackages
};

use DiverHCF\item\netherite\{Helmet, Chestplate, Leggings, Boots, Sword, Pickaxe};


use pocketmine\item\{Item, ItemFactory};

class Items {

	const NETHERITE_HELMET = 748, NETHERITE_CHESTPLATE = 749, NETHERITE_LEGGINGS = 750, NETHERITE_BOOTS = 751, NETHERITE_SWORD = 743, NETHERITE_PICKAXE = 745;
	
	/**
	 * @return void
	 */
	public static function init() : void {
		ItemFactory::registerItem(new EnderPearl(), true);
		ItemFactory::registerItem(new FishingRod(), true);
		ItemFactory::registerItem(new SplashPotion(), true);
		ItemFactory::registerItem(new GoldenApple(), true);
		ItemFactory::registerItem(new GoldenAppleEnchanted(), true);
		ItemFactory::registerItem(new EnderEye(), true);

		ItemFactory::registerItem(new Helmet(), true);
		ItemFactory::registerItem(new Chestplate(), true);
		ItemFactory::registerItem(new Leggings(), true);
		ItemFactory::registerItem(new Boots(), true);
		ItemFactory::registerItem(new Sword(), true);
		ItemFactory::registerItem(new Pickaxe(), true);
		
		ItemFactory::registerItem(new StormBreaker(), true);
		ItemFactory::registerItem(new SecondChance(), true);
		ItemFactory::registerItem(new AntiTrapper(), true);
		ItemFactory::registerItem(new EggPorts(), true);
		ItemFactory::registerItem(new Strength(), true);
		ItemFactory::registerItem(new Resistance(), true);
		ItemFactory::registerItem(new NinjaShear(), true);
		ItemFactory::registerItem(new Resistance(), true);
		ItemFactory::registerItem(new Strength(), true);
		ItemFactory::registerItem(new Invisibility(), true);
		ItemFactory::registerItem(new Firework(), true);
        ItemFactory::registerItem(new Ragebrick(), true);
        ItemFactory::registerItem(new PartnerPackages(), true);
        ItemFactory::registerItem(new LoggerBait(), true);
        ItemFactory::registerItem(new Berserk(), true);
        ItemFactory::registerItem(new Energy(), true);
        ItemFactory::registerItem(new Medkit(), true); 
        ItemFactory::registerItem(new EffectDisabler(), true); 
        ItemFactory::registerItem(new Starvation(), true); 
        ItemFactory::registerItem(new Rageball(), true); 
        ItemFactory::registerItem(new ZombieBardItem(), true); 
        ItemFactory::registerItem(new AntiPearl(), true);
        ItemFactory::registerItem(new Pbard(), true); 
        ItemFactory::registerItem(new Cactus(), true);
        ItemFactory::registerItem(new Timestone(), true);
        ItemFactory::registerItem(new Focusmode(), true);
        ItemFactory::registerItem(new PBackstab(), true);
        ItemFactory::registerItem(new Clogger(), true);
        ItemFactory::registerItem(new CloggerFill(), true);
        
	}

	/**
	 * @param Item $item
	 * @return Array[]
	 */
	public static function itemSerialize(Item $item) : Array {
		$data = $item->jsonSerialize();
		return $data;
	}

	/**
	 * @param Array $items
	 * @return Item
	 */
	public static function itemDeserialize(Array $items) : Item {
		$item = Item::jsonDeserialize($items);
		return $item;
	}
}

?>