<?php

namespace DiverHCF;

use DiverHCF\{Loader, Factions};
use DiverHCF\player\{Player, PlayerBase};
use DiverHCF\crate\CrateManger;
use DiverHCF\translation\Translation;
use DiverHCF\translation\TranslationException;

use DiverHCF\Task\asynctask\{LoadPlayerData, SavePlayerData};

use DiverHCF\Task\Scoreboard;

use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TE;
use pocketmine\level\biome\Biome;

use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerChatEvent, PlayerMoveEvent, PlayerInteractEvent};
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;

use pocketmine\network\mcpe\protocol\LevelEventPacket;

class EventListener implements Listener {

    /**
     * EventListener Constructor.
     */
    public function __construct(){
		
    }
    
    /**
     * @param PlayerCreationEvent $event
     * @return void
     */
    public function onPlayerCreationEvent(PlayerCreationEvent $event) : void {
        $event->setPlayerClass(Player::class, true);
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function onPlayerJoinEvent(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
		$player->sendMessage("§8");
			$player->sendMessage("§8       §6");
			$player->sendMessage("§8      §l§3Freze    ");
			$player->sendMessage("§8  §3Bienvenido a §fHCF MAP #1");
            $player->sendMessage("§8       §6");
			$player->sendMessage("§8");
        $event->setJoinMessage(TE::GRAY."§f[§3Freze§f]§7 [".TE::GREEN."+".TE::GRAY."] ".TE::GREEN.$player->getName().TE::GREEN." entered the Server");
        
        
        
        
        PlayerBase::create($player->getName());
		Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard($player), 20);
        Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new LoadPlayerData($player->getName(), $player->getUniqueId()->toString(), Loader::getDefaultConfig("MySQL")["hostname"], Loader::getDefaultConfig("MySQL")["username"], Loader::getDefaultConfig("MySQL")["password"], Loader::getDefaultConfig("MySQL")["database"], Loader::getDefaultConfig("MySQL")["port"]));
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
		$event->setQuitMessage(TE::GRAY."§f[§3Freze§f]§f [".TE::RED."-".TE::GRAY."] ".TE:: RED.$player->getName().TE::RED." salio del server");

        Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new SavePlayerData($player->getAddress(), Factions::inFaction($player->getName()) ? Factions::getFaction($player->getName()) : "This player not have faction", Loader::getDefaultConfig("MySQL")["hostname"], Loader::getDefaultConfig("MySQL")["username"], Loader::getDefaultConfig("MySQL")["password"], Loader::getDefaultConfig("MySQL")["database"], Loader::getDefaultConfig("MySQL")["port"]));         if($player instanceof Player){             $player->removePermissionsPlayer();
		}
	}
	
	/**
     * @param EntityLevelChangeEvent $event
     * @return void
     */
	public function onEntityLevelChangeEvent(EntityLevelChangeEvent $event) : void {
		$player = $event->getEntity();
		$player->showCoordinates();
	}
    
    /**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
    	$player = $event->getPlayer();
    	$format = null;
    	if($player->getRank() === null||$player->getRank() === "Guest"){
    		$format = TE::GRAY." [".TE::GREEN."Guest".TE::RESET.TE::GRAY."] ".TE::GREEN.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Owner"){
    		$format = TE::GRAY." [".TE::DARK_RED."Owner".TE::RESET.TE::GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Co-Owner"){
    		$format = TE::GRAY." [".TE::RED."Co-Owner".TE::RESET.TE::GRAY."] ".TE::GRAY.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Admin"){
    		$format = TE::GRAY." [".TE::DARK_AQUA."Admin".TE::RESET.TE::GRAY."] ".TE::GRAY.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Sr-Mod"){
    		$format = TE::GRAY." [".TE::DARK_PURPLE."Sr-Mod".TE::RESET.TE::GRAY."] ".TE::GRAY.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Mod"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."Mod".TE::RESET.TE::GRAY."] ".TE::GRAY.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Jr-Admin"){
    		$format = TE::GRAY." [".TE::GREEN."Jr-Admin".TE::RESET.TE::GRAY."] ".TE::GREEN.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Sr-Admin"){
    		$format = TE::GRAY." [".TE::AQUA."Sr-Admin".TE::RESET.TE::GRAY."] ".TE::BOLD.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Developer"){
    		$format = TE::GRAY." [".TE::DARK_AQUA."Developer".TE::GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "9"){
    		$format = TE::GRAY." [".TE::YELLOW."9".TE::RESET.TE::GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	} 
        if($player->getRank() === "Ice"){
              $format = TE::GRAY." [".TE::GOLD."§9Ice".TE::RESET.TE::GRAY."] ".TE::GOLD.$player->getName().TE::WHITE;
         }
       if($player->getRank() === "God"){
    		$format = TE::GRAY." [".TE::DARK_AQUA."§eGod".TE::RESET.TE::GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	} 
		if($player->getRank() === "Angelic"){
    		$format = TE::GRAY." [".TE::DARK_PURPLE."§6Angelic".TE::RESET.TE::GRAY."] ".TE::DARK_PURPLE.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "Freze"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."!!".TE::RESET.TE::RED."§bFreze".TE::LIGHT_PURPLE."!!".TE::RESET.TE::GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "NitroBooster"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."NitroBooster".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Partner"){
    		$format = TE::GRAY." [".TE::OBFUSCATED.TE::WHITE.TE::BOLD."!!".TE::RESET.TE::DARK_PURPLE."Partner".TE::OBFUSCATED.TE::WHITE."!!".TE::RESET.TE::GRAY."] ".TE::DARK_PURPLE.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "YouTube"){
    		$format = TE::GRAY." [".TE::YELLOW."§4You§fTuber".TE::RESET.TE::GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "MiniYT"){
    		$format = TE::GRAY." [".TE::GREEN."§4Mini§fYT".TE::RESET.TE::GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
        }
        if($player->getRank() === "Trainee"){
    		$format = TE::GRAY." [".TE::YELLOW."Trainee".TE::RESET.TE::GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Streamer"){
    		$format = TE::GRAY." [".TE::DARK_PURPLE."Streamer".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Famous"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."Famous".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
         if($player->getRank() === "Co-Founder"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."§9Co-Founder".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
         }
         if($player->getRank() === "Founder"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."§9Founder".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
         }
         if($player->getRank() === "CEO"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."§6C.E.O".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
         }
         if($player->getRank() === "Creador"){
    		$format = TE::GRAY." [".TE::LIGHT_PURPLE."§4<3§7] [§cCreador".TE::RESET.TE::GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
         }
    	if(Factions::inFaction($player->getName())){
			$factionName = Factions::getFaction($player->getName());
			$event->setFormat(TE::GOLD."[".TE::RED.$factionName.TE::GOLD."]".TE::RESET.$format.": ".$event->getMessage());
		}else{
			$event->setFormat(TE::GOLD."[".TE::RED." ".TE::GOLD."]".TE::RESET.$format.": ".$event->getMessage());
		}
	}
}

?>