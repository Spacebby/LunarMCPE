<?php

namespace DiverHCF\reclaim;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\Config;
use pocketmine\item\ItemFactory;

class ReclaimManager {
	
	/** @var Array[] */
	public static $reclaim = [];
	
	/**
	 * @param String $rank
	 * @return bool
	 */
	public static function isReclaim(String $rank) : bool {
		if(isset(self::$reclaim[$rank])){
			return true;
		}else{
			return false;
		}
		return false;
	}
	
	/**
	 * @param Array $args
	 * @return void
	 */
	public static function createReclaim(Array $args = []) : void {
		self::$reclaim[$args["name"]] = new Reclaim($args["name"], !empty($args["contents"]) ? $args["contents"] : []);
	}
	
	/**
	 * @param String $rank
	 * @return void
	 */
	public static function removeReclaim(String $rank) : void {
		unset(self::$reclaim[$rank]);
		$file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."reclaims.yml", Config::YAML);
		$file->remove($rank);
		$file->save();
	}

	/**
	 * @param String $rank
	 * @return reclaim
	 */
	public static function getReclaim(String $rank) : ?Reclaim {
		return self::isReclaim($rank) ? self::$reclaim[$rank] : null;
	}
	
	/**
	 * @return Array[]
	 */
	public static function getReclaims() : Array {
		return self::$reclaim;
	}

	/**
	 * @return String
	 */
	public static function getReclaimsWithString() : String {
		$values = [];
		foreach(array_values(self::getReclaims()) as $val){
			$values[] = $val->getName();
		}
		return implode(", ", $values);
	}

    /**
     * @param Player $player
     * @return void
     */
    public static function giveReclaim(Player $player) : void {
        if(!self::isReclaim($player->getRank())){
            $player->sendMessage(Loader::getConfiguration("messages")->get("reclaim_no_available"));
            return;
        }
        $reclaim = self::getReclaim($player->getRank());
        foreach($reclaim->getItems() as $slot => $item){
            if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
                $player->dropItem($item, true);
				return;
			}
            $player->getInventory()->addItem($item);
        }
		$player->resetReclaimTime();
		Loader::getInstance()->getServer()->broadcastMessage(str_replace(["{playerName}", "{rank}"], [$player->getName(), $player->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
    }
}

?>