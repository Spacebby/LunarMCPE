<?php

namespace DiverHCF\translation;

use Exception;

class TranslationException extends Exception {

}