<?php

declare(strict_types = 1);


namespace DiverHCF\floatingtext;

//Base Libraries
use DiverHCF\Factions;
use DiverHCF\Loader;
use DiverHCF\player\Player;
use pocketmine\level\particle\{FloatingTextParticle};
//DataBase
use DiverHCF\provider\DataProvider as DataBase;
//vector3
use pocketmine\math\Vector3;

class TextManager
{

	public static $crate = [];
	public static $spawn_particles = [];
	public static $texts = [];


	public static function start(Player $player)
	{
		self::spawnCrateText($player);
	}

	public static function spawnCrateText(Player $player): void
	{
	    

		$spawnx = 1;
		$spawny = 74;
		$spawnz = 5;
		$info = self::$texts[$player->getName()]["info"] = new FloatingTextParticle(new Vector3($spawnx + 0.5, $spawny + 2, $spawnz + 0.5), "");
		$info->setTitle("§l§cElemental\n§r§fBienvenido al §r§eMapa 3: §r§fProtection 3, Sharpness 3 \n §r§6Team Size§r§7: §r§f8 Mans, 0 Allys\n \n §r§7§ElementalHCF.ddns.net\n \n §r§7§playElementalHCF.ddns.net");
		$player->getLevel()->addParticle($info, [$player]);


		}
	}
}