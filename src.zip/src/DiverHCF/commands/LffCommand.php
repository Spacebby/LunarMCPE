<?php

namespace DiverHCF\commands;

use DiverHCF\{Loader, Factions};
use DiverHCF\player\player;

use pocketmine\command\{CommandSender, PluginCommand};

use pocketmine\utils\TextFormat as TE;
class LffCommand extends PluginCommand{
  
  public function __construct(){
    parent::__construct("lff", Loader::getInstance());
    $this->setDescription("Search for a faction");
  }
  public function execute(CommandSender $sender, String $label, Array $args): void{
    if(Factions::inFaction($sender->getName())){
    $sender->sendMessage(TE::RED . "You cannot run this command if you are already in a faction");
    return;
    }
    Loader::getInstance()->getServer()->broadcastMessage("§8---------------------------------------------");
		Loader::getInstance()->getServer()->broadcastMessage("§l§4".$sender->getName()." §l§cIs Looking To Join A Faction!");
		Loader::getInstance()->getServer()->broadcastMessage("§8---------------------------------------------");
  }
}