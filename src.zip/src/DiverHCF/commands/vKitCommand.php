<?php

namespace DiverHCF\commands;

use DiverHCF\Loader;
use DiverHCF\vkit\vKitManager;

use DiverHCF\utils\Time;

use DiverHCF\FormAPI\{FormData, MenuForm};

use pocketmine\Player;
use pocketmine\item\ItemFactory;
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class vKitCommand extends PluginCommand {
	
	/**
	 * KitvCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("vkit", Loader::getInstance());
		
		parent::setDescription("Can see the selection of vkits on the server");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		$this->open($sender);
	}
	
	/**
	 * @param Player $player
	 * @return Form
	 */
	protected function open(Player $player){
		$form = new MenuForm(function (Player $player, $data){
			if($data === null){
				return;
			}
			$vkitManager = vKitManager::getvKit($data);
			if(!$player->hasPermission($vkitManager->getPermission())){
				$player->sendMessage(TE::RED."You have not permissions to use this vkit!");
				return;
			}
			if($player->isGodMode()){
				foreach($vkitManager->getItems() as $slot => $item){
					if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
						$player->dropItem($item, true);
					}else{
						$player->getInventory()->addItem($item);
						$player->getArmorInventory()->setContents($vkitManager->getArmorItems());
					}
				}
			}elseif($player->getTimevKitRemaining($vkitManager->getName()) < time()){
				foreach($vkitManager->getItems() as $slot => $item){
					if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
						$player->resetKitTime($vkitManager->getName());
						$player->dropItem($item, true);
					}else{
						$player->resetvKitTime($vkitManager->getName());
						$player->getInventory()->addItem($item);
						$player->getArmorInventory()->setContents($vkitManager->getArmorItems());
					}
				}
			}else{
				$player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($player->getTimevKitRemaining($vkitManager->getName()))], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		});
		$form->setTitle(TE::GOLD.TE::BOLD."VKIT SELECTOR!");
		foreach(vKitManager::getvKits() as $vkit){
			$form->addButton($vkit->getNameFormat().TE::RESET."\n".TE::DARK_GRAY."Click to get!", -1, "", $vkit->getName());
		}
		$player->sendForm($form);
		return $form;
	}
}

?>