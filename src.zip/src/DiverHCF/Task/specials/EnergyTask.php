<?php

namespace DiverHCF\Task\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class EnergyTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * StrengthTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setEnergyTime(Loader::getDefaultConfig("Cooldowns")["Energy"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun(Int $currentTick) : void {
        $player = $this->player;
        if(!$player->isOnline()){
            Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        if($player->getEnergyTime() === 0){
            $player->setEnergy(false);
            Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        }else{
            $player->setEnergyTime($player->getEnergyTime() - 1);
        }
    }
}

?>