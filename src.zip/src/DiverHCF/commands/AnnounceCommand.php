<?php

namespace DiverHCF\commands;

use DiverHCF\Loader;

use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\utils\TextFormat as TE;

use DiverHCF\API\DiscordWebhookAPI\Message;
use DiverHCF\API\DiscordWebhookAPI\Embed;
use DiverHCF\API\DiscordWebhookAPI\Webhook;

class AnnounceCommand extends PluginCommand{
    public function __construct(){
        parent::__construct("alert", Loader::getInstance());
    }
    public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->isOp()){
            $sender->sendMessage(TE::RED."You have not permissions to use this command");
            return;
        }
        if(empty($args[0])) {
                $sender->sendMessage(TE::RED . "Use: /{$label} <message>");
                return;
        }
        $alert = implode(" ", $args);
        $this->sendWebhook($alert, $sender->getName());
        Loader::getInstance()->getServer()->broadcastMessage("§6§lPenguin§r >> " . $alert);
    }
    public function sendWebhook(String $message, String $playerSender){
        $webhook = new Webhook("https://discord.com/api/webhooks/929707639254945812/oECms1yBpOxho2jtQpziBwp7gApcvLhdg7g7XsloZ682Xs3T-RxzoJjm3r_HzWyGqkrx");
        $msg = new Message();

        $msg->setUsername("White | Announces");

        $embed = new Embed();

        $embed->setTitle("New Announce in server!");
        $embed->setDescription($message);
        $embed->setFooter($playerSender);

        $msg->addEmbed($embed);

        $webhook->send($msg);
    }
}
