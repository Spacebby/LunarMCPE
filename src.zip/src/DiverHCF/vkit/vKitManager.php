<?php

namespace DiverHCF\vkit;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\Config;

class vKitManager {
	
	/** @var Array[] */
	public static $vkit = [];
	
	/**
	 * @param String $vkitName
	 * @return bool
	 */
	public static function isvKit(String $vkitName) : bool {
		if(isset(self::$vkit[$vkitName])){
			return true;
		}else{
			return false;
		}
		return false;
	}
	
	/**
	 * @param Array $args
	 * @return void
	 */
	public static function createvKit(Array $args = []) : void {
		self::$vkit[$args["name"]] = new vKit($args["name"], !empty($args["contents"]) ? $args["contents"] : [], !empty($args["armorContents"]) ? $args["armorContents"] : [], $args["permission"], $args["nameFormat"]);
	}
	
	/**
	 * @param String $kitName
	 * @return void
	 */
	public static function removevKit(String $vkitName) : void {
		unset(self::$vkit[$vkitName]);
		$file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."vkits.yml", Config::YAML);
		$file->remove($kitName);
		$file->save();
	}

	/**
	 * @param String $kitName
	 * @return Kit
	 */
	public static function getvKit(String $vkitName) : ?vKit {
		return self::isvKit($vkitName) ? self::$vkit[$vkitName] : null;
	}
	
	/**
	 * @return Array[]
	 */
	public static function getvKits() : Array {
		return self::$vkit;
	}
}

?>