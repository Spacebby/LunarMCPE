<?php

namespace DiverHCF\Task\event;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use DiverHCF\listeners\event\SALE;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class SALETask extends Task {
	
	/**
	 * SALETask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		SALE::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun(Int $currentTick) : void {
		if(!SALE::isEnable()){
			Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
			return;
		}
		if(SALE::getTime() === 0){
			SALE::setEnable(false);
			Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
		}else{
			SALE::setTime(SALE::getTime() - 1);
		}
	}
}

?>