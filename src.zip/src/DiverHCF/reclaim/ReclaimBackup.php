<?php

namespace DiverHCF\reclaim;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use DiverHCF\item\Items;

use pocketmine\utils\{Config, TextFormat as TE};

class ReclaimBackup {

    /**
     * @return void
     */
    public static function initAll() : void {
        $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."reclaims.yml", Config::YAML);
        foreach($file->getAll() as $name => $values){
            self::init($name);
        }
    }

    /**
     * @return void
     */
    public static function saveAll() : void {
        foreach(ReclaimManager::getReclaims() as $name => $values){
            self::save($name);
        }
    }

    /**
     * @param String $name
     * @return void
     */
    public static function init(String $name) : void {
        try {
            $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."reclaims.yml", Config::YAML);
            $reclaimData = $file->getAll()[$name];

            if(isset($reclaimData["contents"])){
                foreach($reclaimData["contents"] as $slot => $item){
                    $reclaimData["contents"][$slot] = Items::itemDeserialize($item);
                }
            }
            ReclaimManager::createReclaim($reclaimData);
        } catch (\Exception $exception) {
            Loader::getInstance()->getLogger()->error("Can't load reclaim: ".$name);  
            Loader::getInstance()->getLogger()->error($exception->getMessage()); 
        }
    }

    /**
     * @param String $name
     * @return void
     */
    public static function save(String $name) : void {
        try {
            $reclaimData = [];

            $reclaim = ReclaimManager::getReclaim($name);
            $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."reclaims.yml", Config::YAML);

            $reclaimData["name"] = $reclaim->getName();

            foreach($reclaim->getItems() as $slot => $item){
                $reclaimData["contents"][$slot] = Items::itemSerialize($item);
            }
            $file->set($reclaim->getName(), $reclaimData);
            $file->save();
        } catch (\Exception $exception){
            Loader::getInstance()->getLogger()->error("Can't save reclaim: ".$name);
            Loader::getInstance()->getLogger()->error($exception->getMessage());
        }
    }
}

?>