<?php

namespace DiverHCF\Task;

use DiverHCF\{Loader, Factions};
use DiverHCF\player\Player;

use DiverHCF\utils\Time;

use DiverHCF\koth\KothManager;

use DiverHCF\Citadel\CitadelManager;

use DiverHCF\listeners\event\{SOTW, EOTW, GiftChest, SALE, PPALL, KEYALL};

use SystemBan\Data\PlayerBase;

use pocketmine\scheduler\Task;
use pocketmine\utils\{Config, TextFormat as TE};

class Scoreboard extends Task {

    /** @var Player */
    protected $player;

    /**
     * Scoreboard Constructor.
     * @param Loader $plugin
     */
    public function __construct(Player $player){
        $this->player = $player;
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun(Int $currentTick) : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        	return;
        }
        if(Factions::isSpawnRegion($player)) $player->setFood(20);

        $config = Loader::getConfiguration("scoreboard_settings");
        $api = Loader::getScoreboard();
        /** @var Array[] */
        $scoreboard = [];
        if($player->isCombatTag()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getCombatTagTime())], $config->get("CombatTag"));
        }
        if($player->isEnderPearl()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEnderPearlTime())], $config->get("EnderPearl"));
        }
        if($player->isStormBreaker()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getStormBreakerTime())], $config->get("StormBreaker"));
        }
        if($player->isAntiPearl()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiPearlTime())], $config->get("AntiPearl"));
        }
        if($player->isStrength()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getStrengthTime())], $config->get("Strength"));
        }
        if($player->isTimestone()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getTimestoneTime())], $config->get("Timestone"));
        } 
        if($player->isFocusmode()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getFocusmodeTime())], $config->get("Focusmode"));
        }
       if($player->isAntiPearl()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiPearlTime())], $config->get("AntiPearl"));
        } 
        if($player->isPbard()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getPbardTime())], $config->get("Pbard"));
        }
       if($player->isMedkit()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getMedkitTime())], $config->get("Medkit"));
        }
        if($player->isRagebrick()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getRagebrickTime())], $config->get("Ragebrick"));
        }
        if($player->isBerserk()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getBerserkTime())], $config->get("Berserk"));
        }
        if($player->isEnergy()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEnergyTime())], $config->get("Energy"));
        }
        if($player->isResistance()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getResistanceTime())], $config->get("Resistance"));
        }
        if($player->isFirework()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getFireworkTime())], $config->get("Firework"));
        }
        if($player->isGoldenGapple()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getGoldenAppleTime())], $config->get("Apple"));
        }
        if($player->isLogout()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getLogoutTime())], $config->get("Logout"));
        }
        if($player->isAntiTrapper()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], $config->get("AntiTrapper"));
        }
        if($player->isRageball()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getRageballTime())], $config->get("Rageball"));
        }
        if($player->isEgg()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEggTime())], $config->get("EggPort"));
        }
        if($player->isBackStab()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getBackstabTime())], $config->get("Backstab"));
        }
        if($player->isSpecialItem()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], $config->get("SpecialItem"));
        }
        if($player->isSecondChance()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSecondChanceTime())], $config->get("SecondChance"));
        }
        if($player->isLoggerBait()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getLoggerBaitTime())], $config->get("LoggerBait"));
        }
        if($player->isNinjaShear()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getNinjaShearTime())], $config->get("NinjaShear"));
        }
        if($player->isArcherTag()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getArcherTagTime())], $config->get("ArcherTag"));
        }
        if($player->isTeleportingHome()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getTeleportingHomeTime())], $config->get("Home"));
        }
        if($player->isTeleportingStuck()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getTeleportingStuckTime())], $config->get("Stuck"));
        }
        if(($kothName = KothManager::kothIsEnabled())){
        	$koth = KothManager::getKoth($kothName);
            $scoreboard[] = str_replace(["&", "{kothName}", "{time}"], ["§", $koth->getName(), Time::getTimeToString($koth->getKothTime())], $config->get("KOTH"));
        }
        if(($citadelName = CitadelManager::CitadelIsEnabled())){
        	$citadel = CitadelManager::getCitadel($citadelName);
            $scoreboard[] = str_replace(["&", "{citadelName}", "{time}"], ["§", $citadel->getName(), Time::getTimeToString($citadel->getCitadelTime())], $config->get("CITADEL"));
        }
        if (isset(loader::$rogue[$player->getName()])) {
            if (loader::$rogue[$player->getName()] - time() < 0) {
                unset(Loader::$rogue[$player->getName()]);
            }
            if (isset(Loader::$rogue[$player->getName()])) {
                $reaming = Loader::$rogue[$player->getName()] - time();
                $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToString($reaming)], $config["ROGUE_DELAY"]);
            }
        }
        if(SOTW::isEnable()){
        	$scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToFullString(SOTW::getTime())], $config->get("SOTW"));
        }
        if(EOTW::isEnable()){
        	$scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToFullString(EOTW::getTime())], $config->get("EOTW"));
        }
        if(KEYALL::isEnable()){
        	$scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToFullString(KEYALL::getTime())], $config->get("KEYALL"));
        }
        if(PPALL::isEnable()){
          $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToFullString(PPALL::getTime())], $config->get("PPALL"));
        }
         if(SALE::isEnable()){
          $scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToFullString(SALE::getTime())], $config->get("SALE"));
        }
        if($player->isInvincibility()){
        	$scoreboard[] = str_replace(["&", "{time}"], ["§", Time::getTimeToFullString($player->getInvincibilityTime())], $config->get("Invincibility"));
        }
        if($player->isBardClass()){
            $scoreboard[] = str_replace(["&", "{bardEnergy}"], ["§", $player->getBardEnergy()], $config->get("BardEnergy"));
        }
        if($player->isArcherClass()){
            $scoreboard[] = str_replace(["&", "{archerEnergy}"], ["§", $player->getArcherEnergy()], $config->get("ArcherEnergy"));
        }
        if($player->isMageClass()){
            $scoreboard[] = str_replace(["&", "{mageEnergy}"], ["§", $player->getMageEnergy()], $config->get("MageEnergy"));
        }
            if($player->isFocus()){
            if(!Factions::isFactionExists($player->getFocusFaction())) $player->setFocus(false);
            foreach($config->get("factionFocus") as $message){
                $scoreboard[] = str_replace(["&", "{factionName}", "{factionHome}", "{factionDTR}", "{factionOnlinePlayers}"], ["§", $player->getFocusFaction(), Factions::getFactionHomeString($player->getFocusFaction()), Factions::getStrength($player->getFocusFaction()), Factions::getOnlinePlayers($player->getFocusFaction())], $message);
            }
        }
        if(!is_null(Loader::getInstance()->getServer()->getPluginManager()->getPlugin("SystemBan"))){
            if(PlayerBase::isStaff($player))
            foreach($config->get("staffmode") as $message){
                $scoreboard[] = str_replace(["&", "{currentTPS}", "{percentageTPS}", "{onlinePlayers}", "{rank}", "{currentGamemode}"], ["§", Loader::getInstance()->getServer()->getTicksPerSecond(), Loader::getInstance()->getServer()->getTickUsage(), count(Loader::getInstance()->getServer()->getOnlinePlayers()), $player->getRank(), $player->getGamemode() === 1 ? "Creative" : "Survival"], $message);
            }
        }
        $claim = TE::RED.$player->getRegion();
        if($player->getRegion() === Factions::getFaction($player->getName())){
          $claim = TE::GREEN.$player->getRegion();
        }
        if($player->getRegion() === "Spawn"){
          $claim = TE::GREEN.$player->getRegion();
        }
        $scoreboard[] = TE::RED.TE::BOLD."Claim".TE::GRAY.": ".$claim;
        
        if(count($scoreboard) >= 1){
            $scoreboard[] = TE::GRAY."";
            $scoreboard[] = TE::GRAY."PenguinHcf.net/19132";
            $texting = [TE::GRAY.TE::GRAY.""];
            
            
      	  $scoreboard = array_merge($texting, $scoreboard);
        }else{
        	$api->removePrimary($player);
        	return;
        }
        $api->newScoreboard($player, $player->getName(), str_replace(["&"], ["§"], $config->get("scoreboard_name")));
        if($api->getObjectiveName($player) !== null){
            foreach($scoreboard as $line => $key){
                $api->remove($player, $scoreboard);
                $api->newScoreboard($player, $player->getName(), str_replace(["&"], ["§"], $config->get("scoreboard_name")));
            }
        }
        foreach($scoreboard as $line => $key){
            $api->setLine($player, $line + 1, $key);
        }
    }
}

?>