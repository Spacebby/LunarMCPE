<?php

namespace DiverHCF\commands;

use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\plugin\Plugin;
use DiverHCF\crate\CrateManager;
use DiverHCF\packages\PackageManager;
use DiverHCF\Loader;
use DiverHCF\player\Player;

class KeyAllgiveCommand extends PluginCommand {
	
	/**
	 * KeyAllCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("keyallg", Loader::getInstance());
		parent::setDescription("Turn on the KEYALL event");
	}
	
	/**
	 * @param CommandSender $player
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */

	public function execute(CommandSender $sender, string $commandLabel, array $args)
	{
	  if($sender->hasPermission("keyall.command.use")){
		    foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $player){
					if ($player instanceof Player) {
						CrateManager::giveKey($player,"Starter", 25);
                             CrateManager::giveKey($player,"Ability", 10);
                             CrateManager::giveKey($player,"Elemental", 10);
                             CrateManager::giveKey($player,"Rare", 10);
                             CrateManager::giveKey($player,"2022", 15);
                             CrateManager::giveKey($player,"Kits", 8);
                             CrateManager::giveKey($player,"Game", 7);
                             CrateManager::giveKey($player,"Extra", 2);
                             CrateManager::giveKey($player,"Ultra", 10);
					}
		    }
					Loader::getInstance()->getServer()->broadcastMessage("§r§c(§4§l!§r§c) §7Everyone online has recieved keys from the KeyAll.");
	  }
		return true;
	}
}