<?php

declare(strict_types = 1);

namespace DiverHCF\translation;

use pocketmine\utils\TextFormat;

interface Messages {

  const MESSAGE = [

    

        "broadcastMessage" => "{message}",

     

    ];

    const RED = "§l§8(§c!§8)§r §7";

    const ORANGE = "§l§8(§6!§8)§r §7";

    const GREEN = "§l§8(§a!§8)§r §7";

    const AQUA = "§l§8(§3!§8)§r §7";

    const PURPLE = "§l§8(§d!§8)§r §7";

    const BLUE = "§l§8(§b!§8)§r §7";

}

