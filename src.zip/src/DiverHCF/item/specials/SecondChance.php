<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\CompoundTag;

class SecondChance extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * SecondChance Constructor.
	 */
	public function __construct(){
		parent::__construct(self::IRON_NUGGET, TE::AQUA.TE::BOLD."SecondChance", [TE::GREEN.TE::BOLD."RARE ITEM".TE::RESET."\n\n".TE::GRAY."Use this to reset your Ender Pearl cooldown"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1))); 
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>