<?php

namespace DiverHCF\commands\moderation;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use DiverHCF\item\specials\{AntiTrapper,
    AntiPearl,
    StormBreaker,
    EggPorts,
    Strength,
    Focusmode, 
    NinjaShear,                        
    Resistance,
    Invisibility,
    EffectDisabler,                        
    Pbard,       
    Cactus,                        
    Firework,  
    Clogger,     
    CloggerFill,                        
    Starvation,                        
    Timestone,                        
    LoggerBait,
    PBackstab,                       
    RageBrick,
    Berserk,
    Energy,    
    Rageball,                        
    ZombieBardItem,                        
    Medkit,                        
    RareBrick};

use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\utils\TextFormat as TE;

class SpecialItemsCommand extends PluginCommand {
	
	/**
	 * SpecialItemsCommand Constructor.
	 */
	public function __construct(){
        parent::__construct("items", Loader::getInstance());
        
        $this->setAliases(["partneritems"]);
        parent::setDescription("Get all special items from the server");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->isOp()){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
        }
        if ($sender instanceof Player) {
            $stormbreaker = new StormBreaker();
            $effectdisabler = new EffectDisabler();
            $antitrapper = new AntiTrapper();
            $eggports = new EggPorts();
            $strength = new Strength();
            $starvation = new Starvation();
            $resistance = new Resistance();
            $invisibility = new Invisibility();
            $ragebrick = new RageBrick();
            $berserk = new Berserk();
            $pbackstab = new PBackstab();
            $rageball = new Rageball();
            $medkit = new Medkit();
            $zombiebarditem = new ZombieBardItem();
            $energy = new Energy();
            $antipearl = new AntiPearl();
            $pbard = new Pbard();
            $timestone = new Timestone();
            $ninjashear = new NinjaShear();
            $cactus = new Cactus();
            $clogger = new Clogger();
            $cloggerfill = new CloggerFill();

            $firework = new Firework();
            $loggerbait = new LoggerBait();

            $sender->getInventory()->addItem($stormbreaker);
            $sender->getInventory()->addItem($antitrapper);
            $sender->getInventory()->addItem($loggerbait);
            $sender->getInventory()->addItem($eggports);
            $sender->getInventory()->addItem($strength);
            $sender->getInventory()->addItem($resistance);
            $sender->getInventory()->addItem($invisibility);
            $sender->getInventory()->addItem($ragebrick);
            $sender->getInventory()->addItem($firework);
            $sender->getInventory()->addItem($berserk);
            $sender->getInventory()->addItem($medkit);
            $sender->getInventory()->addItem($energy);
            $sender->getInventory()->addItem($antipearl); 
            $sender->getInventory()->addItem($starvation);
            $sender->getInventory()->addItem($pbard); 
            $sender->getInventory()->addItem($timestone); 
            $sender->getInventory()->addItem($pbackstab);
            $sender->getInventory()->addItem($ninjashear);
            $sender->getInventory()->addItem($zombiebarditem);
            $sender->getInventory()->addItem($rageball);
            $sender->getInventory()->addItem($cactus);
            $sender->getInventory()->addItem($effectdisabler);
            $sender->getInventory()->addItem($clogger);
            $sender->getInventory()->addItem($cloggerfill);
        }
	}
}

?>