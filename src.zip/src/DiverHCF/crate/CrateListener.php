<?php

namespace DiverHCF\crates;

use pocketmine\level\particle\DestroyBlockParticle;
use pocketmine\math\Vector3;
use DiverHCF\{Loader, Factions};
use DiverHCF\player\Player;

use DiverHCF\API\InvMenu\ChestInventory;

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\event\Listener;
use pocketmine\item\ItemFactory;

use pocketmine\block\Chest;

use pocketmine\math\Vector3;
use pocketmine\event\player\{PlayerJoinEvent, PlayerInteractEvent};
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;

class CrateListener implements Listener
{

    /**
     * Crates Constructor.
     */
    public function __construct()
    {

    }

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function onBlockPlaceEvent(BlockPlaceEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $item = $player->getInventory()->getItemInHand();
        if ($item->getNamedTag()->hasTag("crates")) {
            $tag = $item->getNamedTag()->getString("crates");
            $crateData = CrateManager::getCrate($tag);
            $crateData->setPosition([$block->getX(), $block->getY(), $block->getZ()]);
            $crateData->updateTag();
            $player->sendMessage(str_replace(["&", "{crateName}"], ["ยง", $crateData->getNameFormat()], Loader::getConfiguration("messages")->get("place_crate_correctly")));
        }

    }

    /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function onBlockBreakEvent(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        foreach (CrateManager::getCrates() as $crate) {
            $position = $block->getLevel()->getBlock($block->subtract(0, 1));
            if ($block instanceof Chest && $player->isOp() && $player->isGodMode() && ($type = $crate->isBlock($position->getId(), $position->getDamage()))) {
                $player->sendMessage(str_replace(["&", "{crateName}"], ["ยง", $crate->getNameFormat()], Loader::getConfiguration("messages")->get("remove_crate_correctly")));
            }
        }
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function onPlayerJoinEvent(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        foreach (CrateManager::getCrates() as $crate) {
            $crate->addParticles($player);
        }
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        foreach (array_keys(CrateManager::getCrates()) as $crate) {
            $crateData = CrateManager::getCrate($crate);
            if ($crateData->getPosition() !== null) {
                $position = new Vector3($crateData->getPosition()[0], $crateData->getPosition()[1], $crateData->getPosition()[2]);
                if ($block->getX() === $position->getX()) {
                    if ($block->getY() === $position->getY()) {
                        if ($block->getZ() === $position->getZ()) {
                            if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                                if ($player->getInventory()->getItemInHand()->getCustomName() === $crateData->getKeyName() && ($key = $crateData->isKey($player->getInventory()->getItemInHand()->getId(), $player->getInventory()->getItemInHand()->getDamage()))) {
                                    $this->giveRewards($player, $crateData->getName());
                                    $event->setCancelled(true);
                                    $block->getLevel()->addParticle(new DestroyBlockParticle($block, $block));
                                } else {
                                    $player->sendMessage(TE::RED."No Key!");
                                    $player->setMotion($player->getDirectionVector()->add(-1, 0.3, -1)->multiply(1));
                                }
                            }
                            if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                                $this->seeRewards($player, $crateData->getName());
                                $event->setCancelled(true);
                                $block->getLevel()->addParticle(new DestroyBlockParticle($block, $block));
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param HCFPlayer $player
     * @param String $type
     * @return void
     */
    public function seeRewards(HCFPlayer $player, string $type): void
    {
        $crate = CrateManager::getCrate($type);
        $inventory = new ChestInventory();
        $inventory->setName($crate->getName());
        $inventory->setContents($crate->getItems());
        $inventory->openInventory($player);
    }

    /**
     * @param String $type
     * @return Array[]
     */
    public function getRewards(string $type): array
    {
        $crate = CrateManager::getCrate($type);
        $items = $crate->getItems();

        $item1 = $items[array_rand($items)];
        $item2 = $items[array_rand($items)];
        if (mt_rand(0, 10) === 3) {
            return [$item1, $item2];
        } else {
            return [$item1, $item2];
        }
    }

    /**
     * @param HCFPlayer $player
     * @param String $type
     */
    public function giveRewards(HCFPlayer $player, string $type)
    {
        if (empty($this->getRewards($type))) {
            $player->sendMessage(str_replace(["&"], ["ยง"], HCFLoader::getConfiguration("messages")->get("crate_rewards_empty")));
            return;
        }
        foreach ($this->getRewards($type) as $item) {
            if (!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))) {
                return;
            }
            $player->getInventory()->setItemInHand($player->getInventory()->getItemInHand()->setCount($player->getInventory()->getItemInHand()->getCount() - 1));
        }
    }
}