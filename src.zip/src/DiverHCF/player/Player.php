<?php

namespace DiverHCF\player;

use DiverHCF\{Loader, Factions};

use DiverHCF\enchantments\CustomEnchantment;

use pocketmine\math\Vector3;
use pocketmine\level\Level;

use pocketmine\utils\{Binary, Internet, Config, TextFormat as TE};
use pocketmine\item\{Item, ItemIds};
use pocketmine\entity\{Effect, EffectInstance};

use pocketmine\network\mcpe\protocol\GameRulesChangedPacket;

use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\network\mcpe\protocol\types\CommandData;
use pocketmine\network\mcpe\protocol\types\CommandParameter;
use pocketmine\network\mcpe\protocol\types\CommandEnum;
use pocketmine\network\mcpe\protocol\types\CommandEnumConstraint;
use pocketmine\network\mcpe\protocol\ScriptCustomEventPacket;

class Player extends \pocketmine\Player {

    const LEADER = "Leader", CO_LEADER = "Co_Leader", MEMBER = "Member";

    const FACTION_CHAT = "Faction", PUBLIC_CHAT = "Public", ALLY_CHAT = "Ally";

    /** @var Int */
    protected $bardEnergy = 0, $archerEnergy = 0;

    /** @var Int */
    protected $combatTagTime = 0;

    /** @var Int */
    protected $enderPearlTime = 0;

    /** @var Int */
    protected $stormBreakerTime = 0;
    
    /** @var Int */
    protected $focusmodeTime = 0;
    
    /** @var Int */
    protected $rageballTime = 0;
    
     /** @var Int */
    protected $strengthTime = 0;
    
     /** @var Int */
    protected $timestoneTime = 0;
    
    /** @var Int */
    protected $pbardTime = 0;
    
     /** @var Int */
    protected $fireworkTime = 0;
    
     /** @var Int */
    protected $resistanceTime = 0;
    
     /** @var Int */
    protected $energyTime = 0;
    
    /** @var Int */
    protected $antipearlTime = 0;
    
     /** @var Int */
    protected $ragebrickTime = 0;
    
     /** @var Int */
    protected $berserkTime = 0;
    
     /** @var Int */
    protected $medkitTime = 0;

    /** @var int */
    protected $ninjaShearTime = 0;

    /** @var Int  */
    protected $potionCounterTime = 0;

    /** @var Int */
    protected $antiTrapperTime = 0;

    /** @var Int */
    protected $eggTime = 0;
    
    /** @var Int */
    protected $archerTagTime = 0;
    
    /** @var Int */
    protected $ghostTagTime = 0;
    
    /** @var Int */
    protected $goldenAppleTime = 0;

    /** @var Int */
    protected $playerClaimCost = 0;

    /** @var Int */
    protected $movementTime = 0;
    
    /** @var Int */
    protected $mageEnergy = 0;
    
    /** @var Int */
    protected $ghostEnergy = 0;

    /** @var Int */
    protected $teleportHomeTime = 0, $teleportStuckTime = 0, $logoutTime = 0;
    
    /** @var Int */
    protected $invincibilityTime = 0;

    /** @var Int */
    protected $specialItemTime = 0; 
    
    /** @var Int */
    protected $loggerBaitTime = 0;
              
    /** @var Int */
    protected $effectDisableTime = 0;
    
    /** @var Int */
    protected $prePearlTime = 0;

    /** @var Int */
    protected $rareBrickTime = 0;
    
    /** @var Int */
    protected $loggerBait = 0;
    
    /** @var Int */
    protected $globalItemTime = 0;

    /** @var Int */
    protected $backstabTime = 0;

    /** @var Int */
    protected $secondChanceTime = 0;

    /** @var bool */
    protected $globalItem = false;

    /** @var bool */
    protected $backstab = false;

    /** @var bool */
    protected $secondChance = false;

    /** @var bool */
    protected $badEffects = false;
    
    /** @var bool  */
    protected $potionCounter = false;

    /** @var bool */
    protected $godMode = false;

    /** @var bool */
    protected $combatTag = false;

    /** @var bool */
    protected $enderPearl = false, $prePearl = false;

    /** @var bool */
    protected $stormBreaker = false;
    
    /** @var bool */
    protected $strength = false;
    
    /** @var bool */
    protected $rageball = false;
    
      /** @var bool */
    protected $focusmode = false;
    
    /** @var bool */
    protected $timestone = false;
    
    /** @var bool */
    protected $pbard = false;
    
    /** @var bool */
    protected $firework = false;
    
    /** @var bool */
    protected $resistance = false;
    
    /** @var bool */
    protected $energy = false;
    
     /** @var bool */
    protected $antipearl = false;
    
     /** @var bool */
    protected $ragebrick = false;
    
     /** @var bool */
    protected $berserk = false;
    
    /** @var bool */
    protected $medkit = false;

    /** @var bool */
    protected $ninjaShear = false;
    
    /** @var bool */
    protected $antiTrapper = false, $antiTrapperTarget = false;

    /** @var bool */
    protected $egg = false;
    
    /** @var bool */
    protected $archerTag = false;
    
    /** @var bool */
    protected $ghostTag = false;
    
    /** @var bool */
    protected $goldenApple = false;

    /** @var bool */
    protected $autoFeed = false;

    /** @var bool */
    protected $canInteract = false;
    
    /** @var bool */
    protected $viewingMap = false;

    /** @var bool */
    protected $invitation = false;
    
    /** @var bool */
    protected $invincibility = false;

    /** @var bool */
    protected $specialItem = false;

    /** @var bool */
    protected $focus = false;

    /** @var bool */
    protected $teleportHome = false, $teleportStuck = false, $logout = false;
    
    /** @var String */
    protected $rank = null;

    /** @var String */
    protected $prefix = null;

    /** @var String */
    protected $chat = null;
    
    /** @var String */
    protected $currentInvite = null;
    
    /** @var String */
    protected $currentRegion = null;

    /** @var String */
    protected $focusFaction = null;
    
    /** @var Vector3 */
    protected $ninjaPosition = null;

    /** @var Vector3 */
    protected $prePearlPosition = null;

    /** @var Array[] */
    protected $armorEffects = [];
    
    /** @var Array[] */
    protected $playerClass = [];

    /**
     * @param Int $currentTick
     * @return bool
     */
    public function onUpdate(Int $currentTick) : bool {
        $items = $this->getArmorInventory()->getContents();
        foreach($items as $slot => $item){
            foreach($item->getEnchantments() as $enchantment){
                if($enchantment->getType() instanceof CustomEnchantment){
                    $this->addEffect($enchantment->getType()->getEffectsByEnchantment());
                }
            }
        }
        if($this->isAutoFeed()) $this->setFood(20);
        return parent::onUpdate($currentTick);
    }
    
    /**
     * @param String $server
     * @return bool
     */
    public function transferToServer(?String $server) : bool {
    	$pk = new ScriptCustomEventPacket();
        $pk->eventName = "45.134.8.12:19166";
		$pk->eventData = Binary::writeShort(strlen("Connect")) . "cavehcf.ddns.net:19132" . Binary::writeShort(strlen($server)) . $server;
        $this->sendDataPacket($pk);
        return true;
    }

    /**
     * @param String $rank
     * If the value is null then the Guest rank is placed
     */
    public function setRank(?String $rank = null){
    	$this->rank = $rank;
    }
    
    /**
     * @return String
     */
    public function getRank() : String {
    	return $this->rank === null ? "Guest" : $this->rank;
    }

    /**
     * @param String $prefix
     */
    public function setPrefix(String $prefix = null){
        $this->prefix = $prefix;
    }

    /**
     * @return String|null
     */
    public function getPrefix() : ?String {
        return $this->prefix;
    }

    /**
     * @return Int|null
     */
    public function getBardEnergy() : ?Int {
        return $this->bardEnergy;
    }

    /**
     * @param Int $bardEnergy
     */
    public function setBardEnergy(Int $bardEnergy){
        $this->bardEnergy = $bardEnergy;
    }
    
    /**
     * @return Int|null
     */
    public function getArcherEnergy() : ?Int {
        return $this->archerEnergy;
    }

    /**
     * @param Int $archerEnergy
     */
    public function setArcherEnergy(Int $archerEnergy){
        $this->archerEnergy = $archerEnergy;
    }
    
    /**
     * @return int|null
     */
    public function getMageEnergy(): ?int
    {
        return $this->mageEnergy;
    }

    /**
     * @param int $mageEnergy
     */
    public function setMageEnergy(int $mageEnergy)
    {
        $this->mageEnergy = $mageEnergy;
    }
    
    /**
     * @param Int $itemId|null
     * @return Int
     */
    public function getBardEnergyCost(Int $itemId = null) : Int {
    	$energyCost = null;
    	switch($itemId){
    		case ItemIds::SUGAR:
    		$energyCost = 20;
    		break;
    		case ItemIds::IRON_INGOT:
    		$energyCost = 30;
    		break;
    		case ItemIds::BLAZE_POWDER:
    		$energyCost = 40;
    		break;
    		case ItemIds::GHAST_TEAR:
    		$energyCost = 35;
    		break;
    		case ItemIds::FEATHER:
    		$energyCost = 30;
    		break;
    		case ItemIds::DYE:
    		$energyCost = 30;
    		break;
    		case ItemIds::MAGMA_CREAM:
    		$energyCost = 25;
    		break;
    		case ItemIds::SPIDER_EYE:
    		$energyCost = 40;
    		break;
    	}
    	return $energyCost;
    }
    
        /**
     * @param Int $itemId|null
     * @return Int
     */
    public function getGhostEnergyCost(Int $itemId = null) : Int {
    	$energyCost = null;
    	switch($itemId){
    		case ItemIds::SUGAR:
    		$energyCost = 20;
    		break;
    		case ItemIds::IRON_INGOT:
    		$energyCost = 30;
    		break;
    		case ItemIds::BLAZE_POWDER:
    		$energyCost = 40;
    		break;
    		case ItemIds::GHAST_TEAR:
    		$energyCost = 35;
    		break;
    		case ItemIds::FEATHER:
    		$energyCost = 30;
    		break;
    		case ItemIds::DYE:
    		$energyCost = 30;
    		break;
    		case ItemIds::MAGMA_CREAM:
    		$energyCost = 25;
    		break;
    		case ItemIds::SPIDER_EYE:
    		$energyCost = 40;
    		break;
    	}
    	return $energyCost;
    }
    
    /**
     * @param int|null $itemId
     * @return int|null
     */
    public function getMageEnergyCost(int $itemId = null): ?int
    {
        $energyCost = null;

        switch ($itemId) {
            case ItemIds::SEEDS:
            $energyCost = 35;
            break;
            case ItemIds::COAL:
            $energyCost = 25;
            break;
            case ItemIds::SPIDER_EYE:
            $energyCost = 40;
            break;
            case ItemIds::ROTTEN_FLESH:
            $energyCost = 40;
            break;
            case ItemIds::GOLD_NUGGET:
            $energyCost = 35;
            break;
            case ItemIds::DYE:
            $energyCost = 30;
            break;
        }
        return $energyCost;
    }

    /**
     * @return bool
     */
    public function isGodMode() : bool {
        return $this->godMode;
    }

    /**
     * @param bool $godMode
     */
    public function setGodMode(bool $godMode){
        $this->godMode = $godMode;
    }

    /**
     * @return bool
     */
    public function isCombatTag() : bool {
        return $this->combatTag;
    }

    /**
     * @param bool $combatTag
     */
    public function setCombatTag(bool $combatTag){
        $this->combatTag = $combatTag;
    }
    
    /**
     * @param Int $combatTagTime
     */
    public function setCombatTagTime(Int $combatTagTime){
    	$this->combatTagTime = $combatTagTime;
    }
    
    /**
     * @return Int
     */
    public function getCombatTagTime() : Int {
    	return $this->combatTagTime;
    }

    /**
     * @return bool
     */
    public function isEnderPearl() : bool {
        return $this->enderPearl;
    }
    
    /**
     * @param bool $enderPearl
     */
    public function setEnderPearl(bool $enderPearl){
        $this->enderPearl = $enderPearl;
    }
    
    /**
     * @param Int $enderPearlTime
     */
    public function setEnderPearlTime(Int $enderPearlTime){
    	$this->enderPearlTime = $enderPearlTime;
    }
    
    /**
     * @return Int
     */
    public function getEnderPearlTime() : Int {
    	return $this->enderPearlTime;
    }

    /**
     * @return bool
     */
    public function isStormBreaker() : bool {
        return $this->stormBreaker;
    }
    
    /**
     * @param bool $stormBreaker
     */
    public function setStormBreaker(bool $stormBreaker){
        $this->stormBreaker = $stormBreaker;
    }
    
    /**
     * @param Int $stormBreakerTime
     */
    public function setStormBreakerTime(Int $stormBreakerTime){
    	$this->stormBreakerTime = $stormBreakerTime;
    }
    
    /**
     * @return Int
     */
    public function getStormBreakerTime() : Int {
    	return $this->stormBreakerTime;
    }
    
     /**
     * @return bool
     */
    public function isStrength() : bool {
        return $this->strength;
    }
    
    /**
     * @param bool $strength
     */
    public function setStrength(bool $strength){
        $this->strength = $strength;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setStrengthTime(Int $strengthTime){
    	$this->strengthTime = $strengthTime;
    }
    
    /**
     * @return Int
     */
    public function getStrengthTime() : Int {
    	return $this->strengthTime;
    }
    
    /**
     * @return bool
     */
    public function isAntiPearl() : bool {
        return $this->antipearl;
    }
    
    /**
     * @param bool $stormBreaker
     */
    public function setAntiPearl(bool $antipearl){
        $this->antipearl = $antipearl;
    }
    
    /**
     * @param Int $stormBreakerTime
     */
    public function setAntiPearlTime(Int $antipearlTime){
    	$this->antipearlTime = $antipearlTime;
    }
    
    /**
     * @return Int
     */
    public function getAntiPearlTime() : Int {
    	return $this->antipearlTime;
    }
    
     /**
     * @return bool
     */
    public function isFocusmode() : bool {
        return $this->focusmode;
    }
    
    /**
     * @param bool $strength
     */
    public function setFocusmode(bool $focusmode){
        $this->focusmode = $focusmode;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setFocusmodeTime(Int $focusmodeTime){
    	$this->focusmodeTime = $focusmodeTime;
    }
    
    /**
     * @return Int
     */
    public function getFocusmodeTime() : Int {
    	return $this->focusmodeTime;
    }
    
        /**
     * @return bool
     */
    public function isRageball() : bool {
        return $this->rageball;
    }
    
    /**
     * @param bool $stormBreaker
     */
    public function setRageball(bool $rageball){
        $this->rageball = $rageball;
    }
    
    /**
     * @param Int $stormBreakerTime
     */
    public function setRageballTime(Int $rageballTime){
    	$this->rageballTime = $rageballTime;
    }
    
    /**
     * @return Int
     */
    public function getRageballTime() : Int {
    	return $this->rageballTime;
    }
    
     /**
     * @return bool
     */
    public function isTimestone() : bool {
        return $this->timestone;
    }
    
    /**
     * @param bool $strength
     */
    public function setTimestone(bool $timestone){
        $this->timestone = $timestone;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setTimestoneTime(Int $timestoneTime){
    	$this->timestoneTime = $timestoneTime;
    }
    
    /**
     * @return Int
     */
    public function getTimestoneTime() : Int {
    	return $this->timestoneTime;
    }
    
     /**
     * @return bool
     */
    public function isPbard() : bool {
        return $this->pbard;
    }
    
    /**
     * @param bool $strength
     */
    public function setPbard(bool $pbard){
        $this->pbard = $pbard;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setPbardTime(Int $pbardTime){
    	$this->pbardTime = $pbardTime;
    }
    
    /**
     * @return Int
     */
    public function getPbardTime() : Int {
    	return $this->pbardTime;
    }
    
    /**
     * @return bool
     */
    public function isRagebrick() : bool {
        return $this->ragebrick;
    }
    
    /**
     * @param bool $strength
     */
    public function setRagebrick(bool $ragebrick){
        $this->ragebrick = $ragebrick;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setRagebrickTime(Int $ragebrickTime){
    	$this->ragebrickTime = $ragebrickTime;
    }
    
    /**
     * @return Int
     */
    public function getRagebrickTime() : Int {
    	return $this->ragebrickTime;
    } 
    
     /**
     * @return bool
     */
    public function isFirework() : bool {
        return $this->firework;
    }
    
    /**
     * @param bool $strength
     */
    public function setFirework(bool $firework){
        $this->firework = $firework;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setFireworkTime(Int $fireworkTime){
    	$this->fireworkTime = $fireworkTime;
    }
    
    /**
     * @return Int
     */
    public function getFireworkTime() : Int {
    	return $this->fireworkTime;
    } 
    
     /**
     * @return bool
     */
    public function isResistance() : bool {
        return $this->resistance;
    }
    
    /**
     * @param bool $strength
     */
    public function setResistance(bool $resistance){
        $this->resistance = $resistance;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setResistanceTime(Int $resistanceTime){
    	$this->resistanceTime = $resistanceTime;
    }
    
    /**
     * @return Int
     */
    public function getResistanceTime() : Int {
    	return $this->resistanceTime;
    }
   
    /**
     * @return bool
     */
    public function isEnergy() : bool {
        return $this->energy;
    }
    
    /**
     * @param bool $strength
     */
    public function setenergy(bool $energy){
        $this->energy = $energy;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setEnergyTime(Int $energyTime){
    	$this->energyTime = $energyTime;
    }
    
    /**
     * @return Int
     */
    public function getEnergyTime() : Int {
    	return $this->energyTime;
    }
   
    /**
     * @return bool
     */
    public function isMedkit() : bool {
        return $this->medkit;
    }
    
    /**
     * @param bool $medkit
     */
    public function setMedkit(bool $medkit){
        $this->medkit = $medkit;
    }
    
    /**
     * @param Int $medkitTime
     */
    public function setMedkitTime(Int $medkitTime){
    	$this->medkitTime = $medkitTime;
    }
    
    /**
     * @return Int
     */
    public function getMedkitTime() : Int {
    	return $this->medkitTime;
    }
    
    /**
     * @return bool
     */
    public function isRaidersrageTarget() : bool {
        return $this->raidersrageTarget;
    }

    /**
     * @param bool $antiTrapperTarget
     */
    public function setRaidersrageTarget(bool $raidersrageTarget){
        $this->raidersrageTarget = $raidersrageTarget;
    }

    /**
     * @return bool
     */
    public function isRaidersrage() : bool {
        return $this->raidersrage;
    }
    
    /**
     * @param bool $antiTrapper
     */
    public function setRaidersrage(bool $raidersrage){
        $this->raidersrage = $raidersrage;
    }
    
    /**
     * @param Int $antiTrapperTime
     */
    public function setRaidersrageTime(Int $raidersrageTime){
    	$this->raidersrageTime = $raidersrageTime;
    }
    
    /**
     * @return Int
     */
    public function getRaidersrageTime() : Int {
    	return $this->raidersrageTime;
    }
    
     /**
     * @return bool
     */
    public function isBerserk() : bool {
        return $this->berserk;
    }
    
    /**
     * @param bool $strength
     */
    public function setBerserk(bool $berserk){
        $this->berserk = $berserk;
    }
    
    /**
     * @param Int $strengthTime
     */
    public function setBerserkTime(Int $berserkTime){
    	$this->berserkTime = $berserkTime;
    }
    
    /**
     * @return Int
     */
    public function getBerserkTime() : Int {
    	return $this->berserkTime;
    } 
    
    /**
     * @return bool
     */
    public function isAntiTrapperTarget() : bool {
        return $this->antiTrapperTarget;
    }

    /**
     * @param bool $antiTrapperTarget
     */
    public function setAntiTrapperTarget(bool $antiTrapperTarget){
        $this->antiTrapperTarget = $antiTrapperTarget;
    }

    /**
     * @return bool
     */
    public function isAntiTrapper() : bool {
        return $this->antiTrapper;
    }
    
    /**
     * @param bool $antiTrapper
     */
    public function setAntiTrapper(bool $antiTrapper){
        $this->antiTrapper = $antiTrapper;
    }
    
    /**
     * @param Int $antiTrapperTime
     */
    public function setAntiTrapperTime(Int $antiTrapperTime){
    	$this->antiTrapperTime = $antiTrapperTime;
    }
    
    /**
     * @return Int
     */
    public function getAntiTrapperTime() : Int {
    	return $this->antiTrapperTime;
    }
    
    /**
     * @return bool
     */
    public function isArcherTag() : bool {
    	return $this->archerTag;
    }
    
    /**
     * @param bool $archerTag
     */
    public function setArcherTag(bool $archerTag){
    	$this->archerTag = $archerTag;
    }
    
    /**
     * @param Int $archerTagTime
     */
    public function setArcherTagTime(Int $archerTagTime){
    	$this->archerTagTime = $archerTagTime;
    }
    
    /**
     * @return Int
     */
    public function getArcherTagTime() : Int {
    	return $this->archerTagTime;
    }

    /**
     * @return bool
     */
    public function isEgg() : bool {
        return $this->egg;
    }

    /**
     * @param bool $egg
     */
    public function setEgg(bool $egg){
        $this->egg = $egg;
    }

    /**
     * @param Int $eggTime
     */
    public function setEggTime(Int $eggTime){
        $this->eggTime = $eggTime;
    }

    /**
     * @return Int
     */
    public function getEggTime() : Int {
        return $this->eggTime;
    }

    /**
     * @return bool
     */
    public function isSpecialItem() : bool {
        return $this->specialItem;
    }

    /**
     * @param bool $specialItem
     */
    public function setSpecialItem(bool $specialItem){
        $this->specialItem = $specialItem;
    }

    /**
     * @param Int $specialItemTime
     */
    public function setSpecialItemTime(Int $specialItemTime){
        $this->specialItemTime = $specialItemTime;
    }

    /**
     * @return Int
     */
    public function getSpecialItemTime() : Int {
        return $this->specialItemTime;
    }

    /**
     * @return bool
     */
    public function isPotionCounter() : bool {
        return $this->potionCounter;
    }

    /**
     * @param bool $potionCounter
     */
    public function setPotionCounter(bool $potionCounter){
        $this->potionCounter = $potionCounter;
    }

    /**
     * @param Int $potionCounterTime
     */
    public function setPotionCounterTime(Int $potionCounterTime){
        $this->potionCounterTime = $potionCounterTime;
    }

    /**
     * @return Int
     */
    public function getPotionCounterTime() : Int {
        return $this->potionCounterTime;
    }
    
    /**
     * @return bool
     */
    public function isRareBrick() : bool {
        return $this->rareBrick;
    }

    /**
     * @param bool $rareBrick
     */
    public function setRareBrick(bool $rareBrick){
        $this->rareBrick = $rareBrick;
    }

    /**
     * @param Int $rareBrickTime
     */
    public function setRareBrickTime(Int $rareBrickTime){
        $this->rareBrickTime = $rareBrickTime;
    }

    /**
     * @return Int
     */
    public function getRareBrickTime() : Int {
        return $this->rareBrickTime;
    }
    
    /**
     * @return bool
     */
    public function isLoggerBait() : bool {
        return $this->loggerBait;
    }
    
    /**
     * @param bool $loggerBait
     */
    public function setLoggerBait(bool $loggerBait){
        $this->loggerBait = $loggerBait;
    }
    
    /**
     * @param Int $loggerBaitTime
     */
    public function setLoggerBaitTime(Int $loggerBait){
        $this->loggerBaitTime = $loggerBait;
    }
    
    /**
     * @return Int
     */
    public function getLoggerBaitTime() : Int {
        return $this->loggerBaitTime;
    }
    
   /**
     * @return bool
     */
    public function isNinjaShear() : bool {
        return $this->ninjaShear;
    }

    /**
     * @param bool $ninjaShear
     */
    public function setNinjaShear(bool $ninjaShear){
        $this->ninjaShear = $ninjaShear;
    }

    /**
     * @param Int $ninjaShearTime
     */
    public function setNinjaShearTime(Int $ninjaShearTime){
        $this->ninjaShearTime = $ninjaShearTime;
    }

    /**
     * @return Int
     */
    public function getNinjaShearTime() : Int {
        return $this->ninjaShearTime;
    }

    /**
     * @param Vector3 $ninjaPosition
     */
    public function setNinjaShearPosition(?Vector3 $ninjaPosition){
        $this->ninjaPosition = $ninjaPosition;
    }

    /**
     * @return Vector3
     */
    public function getNinjaShearPosition() : ?Vector3 {
        return $this->ninjaPosition;
    }

    /**
     * @return bool
     */
    public function isPrePearl() : bool {
        return $this->prePearl;
    }

    /**
     * @param bool $prePearl
     */
    public function setPrePearl(bool $prePearl){
        $this->prePearl = $prePearl;
    }

    /**
     * @param Vector3 $prePearlPosition
     */
    public function setPrePearlPosition(?Vector3 $prePearlPosition){
        $this->prePearlPosition = $prePearlPosition;
    }

    /**
     * @return Vector3
     */
    public function getPrePearlPosition() : ?Vector3 {
        return $this->prePearlPosition;
    }
    
    /**
     * @return bool
     */
    public function isGoldenGapple() : bool {
    	return $this->goldenApple;
    }
    
    /**
     * @param bool $goldenApple
     */
    public function setGoldenApple(bool $goldenApple){
    	$this->goldenApple = $goldenApple;
    }
    
    /**
     * @param Int $goldenAppleTime
     */
    public function setGoldenAppleTime(Int $goldenAppleTime){
    	$this->goldenAppleTime = $goldenAppleTime;
    }
    
    /**
     * @return Int
     */
    public function getGoldenAppleTime() : Int {
    	return $this->goldenAppleTime;
    }

    /**
     * @return bool
     */
    public function isBackStab() : bool {
    	return $this->backstab;
    }
    
    /**
     * @param bool $backstap
     */
    public function setBackstab(bool $backstab){
    	$this->backstab = $backstab;
    }
    
    /**
     * @param Int $backstapTime
     */
    public function setBackstabTime(Int $backstabTime){
    	$this->backstabTime = $backstabTime;
    }
    
    /**
     * @return Int
     */
    public function getBackstabTime() : Int {
    	return $this->backstabTime;
    }

    /**
     * @return bool
     */
    public function isSecondChance() : bool {
        return $this->secondChance;
    }
    
    /**
     * @param bool $secondChance
     */
    public function setSecondChance(bool $secondChance){
        $this->secondChance = $secondChance;
    }
    
    /**
     * @param Int $secondChanceTime
     */
    public function setSecondChanceTime(Int $secondChanceTime){
    	$this->secondChanceTime = $secondChanceTime;
    }
    
    /**
     * @return Int
     */
    public function getSecondChanceTime() : Int {
    	return $this->secondChanceTime;
    }

    /**
     * @return bool
     */
    public function isAutoFeed() : bool {
        return $this->autoFeed;
    }

    /**
     * @param bool $autoFeed
     */
    public function setAutoFeed(bool $autoFeed){
        $this->autoFeed = $autoFeed;
    }

    /**
     * @return bool
     */
    public function isTeleportingHome() : bool {
        return $this->teleportHome;
    }

    /**
     * @param bool $teleportHome
     */
    public function setTeleportingHome(bool $teleportHome){
        $this->teleportHome = $teleportHome;
    }

    /**
     * @param Int $teleportHomeTime
     */
    public function setTeleportingHomeTime(Int $teleportHomeTime){
        $this->teleportHomeTime = $teleportHomeTime;
    }

    /**
     * @return Int
     */
    public function getTeleportingHomeTime() : Int {
        return $this->teleportHomeTime;
    }
    
    /**
     * @return bool
     */
    public function isLogout() : bool {
        return $this->logout;
    }

    /**
     * @param bool $logout
     */
    public function setLogout(bool $logout){
        $this->logout = $logout;
    }

    /**
     * @param Int $logoutTime
     */
    public function setLogoutTime(Int $logoutTime){
        $this->logoutTime = $logoutTime;
    }

    /**
     * @return Int
     */
    public function getLogoutTime() : Int {
        return $this->logoutTime;
    }
    
    /**
     * @return bool
     */
    public function isTeleportingStuck() : bool {
        return $this->teleportStuck;
    }

    /**
     * @param bool $teleportStuck
     */
    public function setTeleportingStuck(bool $teleportStuck){
        $this->teleportStuck = $teleportStuck;
    }

    /**
     * @param Int $teleportStuckTime
     */
    public function setTeleportingStuckTime(Int $teleportStuckTime){
        $this->teleportStuckTime = $teleportStuckTime;
    }

    /**
     * @return Int
     */
    public function getTeleportingStuckTime() : Int {
        return $this->teleportStuckTime;
    }
    
    /**
     * @return bool
     */
    public function isInvincibility() : bool {
    	return $this->invincibility;
    }
    
    /**
     * @param bool $invincibility
     */
    public function setInvincibility(bool $invincibility){
    	$this->invincibility = $invincibility;
    }
    
    /**
     * @param Int $invincibilityTime
     */
    public function setInvincibilityTime(Int $invincibilityTime){
    	$this->invincibilityTime = $invincibilityTime;
    }
    
    /**
     * @return Int
     */
    public function getInvincibilityTime() : Int {
    	return $this->invincibilityTime;
    }

    /**
     * @return bool
     */
    public function isViewingMap() : bool {
    	return $this->viewingMap;
    }
    
    /**
     * @param bool $viewingMap
     */
    public function setViewingMap(bool $viewingMap){
    	$this->viewingMap = $viewingMap;
    }

    /**
     * @param mixed $movementTime
     */
    public function setMovementTime($movementTime){
        $this->movementTime = $movementTime;
    }

    /**
     * @return bool
     */
    public function isMovementTime() : bool {
        return (time() - $this->movementTime) < 0;
    }

    /**
     * @return bool
     */
    public function isInteract() : bool {
        return $this->canInteract;
    }

    /**
     * @param bool $canInteract
     */
    public function setInteract(bool $canInteract){
        $this->canInteract = $canInteract;
    }
    
    /**
     * @return void
     */
    public function addTool() : void {
    	$item = Item::get(ItemIds::WOODEN_HOE, 0, 1)->setCustomName(TE::GREEN."Claiming Wand")->setLore([TE::GRAY."Touch First Position, Break Second Position!"]);
		$this->getInventory()->addItem($item);
    }
    
    /**
     * @return void
     */
    public function removeTool() : void {
    	$this->getInventory()->removeItem(Item::get(ItemIds::WOODEN_HOE, 0, 1));
    }

    /**
     * @return Int
     */
    public function getClaimCost() : Int {
        return $this->playerClaimCost;
    }

    /**
     * @param Int $playerClaimCost
     */
    public function setClaimCost(Int $playerClaimCost){
        $this->playerClaimCost = $playerClaimCost;
    }

    /**
     * @param String $chat
     */
    public function setChat(String $chat){
        $this->chat = $chat;
    }

    /**
     * @return String
     */
    public function getChat() : ?String {
        return $this->chat === null ? "Public" : $this->chat;
    }

    /**
     * @return bool
     */
    public function isInvited() : bool {
        return $this->invitation;
    }

    /**
     * @param bool $invitation
     */
    public function setInvite(bool $invitation){
        $this->invitation = $invitation;
    }
    
    /**
     * @return String
     */
    public function getCurrentInvite() : String {
    	return $this->currentInvite;
    }
    
    /**
     * @param String $currentInvite
     */
    public function setCurrentInvite(String $currentInvite){
    	$this->currentInvite = $currentInvite;
    }

    /**
     * @return bool
     */
    public function isFocus() : bool {
        return $this->focus;
    }

    /**
     * @param bool $focus
     */
    public function setFocus(bool $focus){
        $this->focus = $focus;
    }

    /**
     * @param String $focusFaction
     */
    public function setFocusFaction(String $focusFaction){
        $this->focusFaction = $focusFaction;
    }

    /**
     * @return void
     */
    public function getFocusFaction() : String {
        return $this->focusFaction;
    }

    /**
     * @return String
     */
    public function getRegion() : String {
    	return $this->currentRegion === null ? "Unknown" : $this->currentRegion;
    }
    
    /**
     * @param String $currentRegion
     */
    public function setRegion(String $currentRegion){
    	$this->currentRegion = $currentRegion;
    }
    
    /**
     * @return String
     */
    public function getCurrentRegion() : String {
    	if(Factions::isSpawnRegion($this)){
    		return "Spawn";
    	}else{
    		return Factions::getRegionName($this) ?? "Wilderness";
    	}
    }
    
    /**
     * @return Int
     */
    public function getLives() : Int {
        return PlayerBase::getData($this->getName())->get("lives") === null ? 0 : PlayerBase::getData($this->getName())->get("lives");
    }
    
    /**
     * @param Int $lives
     */
    public function setLives(Int $lives){
        PlayerBase::setData($this->getName(), "lives", $lives);
    }

    /**
     * @param Int $lives
     */
    public function reduceLives(Int $lives){
        PlayerBase::setData($this->getName(), "lives", $this->getLives() - $lives);
    }

    /**
     * @param Int $lives
     */
    public function addLives(Int $lives){
        PlayerBase::setData($this->getName(), "lives", $this->getLives() + $lives);
    }

    /**
     * @return Int
     */
    public function getBalance() : Int {
    	return PlayerBase::getData($this->getName())->get("balance") === null ? 500 : PlayerBase::getData($this->getName())->get("balance");
    }

    /**
     * @param Int $balance
     */
    public function setBalance(Int $balance){
    	PlayerBase::setData($this->getName(), "balance", $balance);
    }
    

    /**
     * @param Int $balance
     */
    public function reduceBalance(Int $balance){
        PlayerBase::setData($this->getName(), "balance", $this->getBalance() - $balance);
    }

    /**
     * @param Int $balance
     */
    public function addBalance(Int $balance){
        PlayerBase::setData($this->getName(), "balance", $this->getBalance() + $balance);
    }

    /**
     * @param Int $kills
     */
    public function setKills(Int $kills){
        PlayerBase::setData($this->getName(), "kills", $kills);
    }

    /**
     * @return Int
     */
    public function getKills() : Int {
        return PlayerBase::getData($this->getName())->get("kills") === null ? 0 : PlayerBase::getData($this->getName())->get("kills");
    }

    /**
     * @param Int $kills
     */
    public function reduceKills(Int $kills = 1){
        PlayerBase::setData($this->getName(), "kills", $this->getKills() - $kills);
    }
    
    /**
     * @param Int $kills
     */
    public function addKills(Int $kills = 1){
    	PlayerBase::setData($this->getName(), "kills", $this->getKills() + $kills);
    }

    /**
     * @param String $kitName
     * @return Int
     */
    public function getTimeKitRemaining(String $kitName) : Int {
        return PlayerBase::getData($this->getName())->get($kitName);
    }

    /**
     * @param String $kitName
     */
    public function resetKitTime(String $kitName){
        PlayerBase::setData($this->getName(), $kitName, time() + (4 * 3600));
    }

    /**
     * @return Int
     */
    public function getTimeBrewerRemaining() : Int {
        return PlayerBase::getData($this->getName())->get("brewer");
    }

    /**
     * @return void
     */
    public function resetBrewerTime() : void {
        PlayerBase::setData($this->getName(), "brewer", time() + (4 * 3600));
    }

    /**
     * @return Int
     */
    public function getTimeReclaimRemaining() : Int {
        return PlayerBase::getData($this->getName())->get("reclaim");
    }

    /**
     * @return void
     */
    public function resetReclaimTime() : void {
        PlayerBase::setData($this->getName(), "reclaim", time() + (1 * 604800));
    }
      /**
     * @param String $vkitName
     * @return Int
     */
     public function getTimevKitRemaining(String $vkitName) : Int {
        return PlayerBase::getData($this->getName())->get($vkitName);
    }

    /**
     * @param String $vkitName
     */
    public function resetvKitTime(String $vkitName){
        PlayerBase::setData($this->getName(), $vkitName, time() + (2 * 28800));
    }

     
     /**
     * @return Int
     */
    public function getTimeRedeemRemaining() : Int {
        return PlayerBase::getData($this->getName())->get("redeem");
    }

    /**
     * @return void
     */
    public function resetRedeemTime() : void {
        PlayerBase::setData($this->getName(), "redeem", time() + (1 * 999999999));
    }
   /**

     * @return Int

     */

    public function getTimeDailyRemaining() : Int {

        return PlayerBase::getData($this->getName())->get("daily");

    }

    /**

     * @return void

     */

    public function resetDailyTime() : void {

        PlayerBase::setData($this->getName(), "daily", time() + (1 * 86400));

    }

    /**
     * @return Int
     */
    public function getKothHostTimeRemaining() : Int {
        return PlayerBase::getData($this->getName())->get("koth_host");
    }

    /**
     * @return void
     */
    public function resetKothHostTime() : void {
        PlayerBase::setData($this->getName(), "koth_host", $this->getRank() === "Eternal" ? time() + (2 * 3600) : time() + (3 * 3600));
    }
    
    /**
     * @return Int
     */
    public function getCitadelHostTimeRemaining() : Int {
        return PlayerBase::getData($this->getName())->get("citadel_host");
    }

    /**
     * @return void
     */
    public function resetCitadelHostTime() : void {
        PlayerBase::setData($this->getName(), "citadel_host", $this->getRank() === "Eternal" ? time() + (2 * 3600) : time() + (3 * 3600));
    }
    
    /**
     * @return bool
     */
     public function isBardClass() : bool {
    	if(!$this->isOnline()) return false;
		if($this->getArmorInventory()->getHelmet()->getId() === ItemIds::GOLD_HELMET && $this->getArmorInventory()->getChestplate()->getId() === ItemIds::GOLD_CHESTPLATE && $this->getArmorInventory()->getLeggings()->getId() === ItemIds::GOLD_LEGGINGS && $this->getArmorInventory()->getBoots()->getId() === ItemIds::GOLD_BOOTS){
			return true;
		}else{
			return false;
		}
		return false;
    }
    
    /**
     * @return bool
     */
    public function isMageClass(): bool
    {
        if (!$this->isOnline())
            return false;

        if ($this->getArmorInventory()->getHelmet()->getId() === ItemIds::GOLD_HELMET && $this->getArmorInventory()->getChestplate()->getId() === ItemIds::CHAINMAIL_CHESTPLATE && $this->getArmorInventory()->getLeggings()->getId() === ItemIds::CHAINMAIL_LEGGINGS && $this->getArmorInventory()->getBoots()->getId() === ItemIds::GOLD_BOOTS) {
            return true;
        }
        return false;
    }
    
    /**
     * @return bool
     */
    public function isArcherClass() : bool {
    	if(!$this->isOnline()) return false;
		if($this->getArmorInventory()->getHelmet()->getId() === ItemIds::LEATHER_HELMET && $this->getArmorInventory()->getChestplate()->getId() === ItemIds::LEATHER_CHESTPLATE && $this->getArmorInventory()->getLeggings()->getId() === ItemIds::LEATHER_LEGGINGS && $this->getArmorInventory()->getBoots()->getId() === ItemIds::LEATHER_BOOTS){
			return true;
		}else{
			return false;
		}
		return false;
    }
    
    /**
     * @return bool
     */
    public function isMinerClass() : bool {
    	if(!$this->isOnline()) return false;
		if($this->getArmorInventory()->getHelmet()->getId() === ItemIds::IRON_HELMET && $this->getArmorInventory()->getChestplate()->getId() === ItemIds::IRON_CHESTPLATE && $this->getArmorInventory()->getLeggings()->getId() === ItemIds::IRON_LEGGINGS && $this->getArmorInventory()->getBoots()->getId() === ItemIds::IRON_BOOTS){
			return true;
		}else{
			return false;
		}
		return false;
    }

    /**
     * @return bool
     */
    public function isRogueClass() : bool {
        if(!$this->isOnline()) return false;
		if($this->getArmorInventory()->getHelmet()->getId() === ItemIds::CHAINMAIL_HELMET && $this->getArmorInventory()->getChestplate()->getId() === ItemIds::CHAINMAIL_CHESTPLATE && $this->getArmorInventory()->getLeggings()->getId() === ItemIds::CHAINMAIL_LEGGINGS && $this->getArmorInventory()->getBoots()->getId() === ItemIds::CHAINMAIL_BOOTS){
			return true;
		}else{
			return false;
		}
		return false;
    }
    
    /**
     * @return void
     */
    public function checkClass() : void {
        if($this->isBardClass()){
            if(!isset($this->armorEffects[$this->getName()]["Bard"])){
                $this->armorEffects[$this->getName()]["Bard"] = $this;
            $this->sendMessage(" \n§aActivated Class §l§7--> §6Bard\n ");    
            }
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 240, 1));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 240, 1));
        }elseif($this->isArcherClass()){
        	if(!isset($this->armorEffects[$this->getName()]["Archer"])){
                $this->armorEffects[$this->getName()]["Archer"] = $this;
            $this->sendMessage(" \n§aActivated Class §l§7--> §dArcher\n ");    
            }
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 240, 1));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 240, 1));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 240, 2));
        }elseif($this->isRogueClass()){
            if(!isset($this->armorEffects[$this->getName()]["Rogue"])){
                $this->armorEffects[$this->getName()]["Rogue"] = $this;
            $this->sendMessage(" \n§aActivated Class §l§7--> §9Rogue\n ");    
            }
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 240, 1));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 240, 1));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 240, 2));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 240, 1));
        }elseif($this->isMageClass()) {
          // TODO:
          if(!isset($this->playerClass[$this->getName()]["Mage"])){
              $this->playerClass[$this->getName()]["Mage"] = $this;
          $this->sendMessage(" \n§aActivated Class §l§7--> §2Mage\n ");   
          }
          $this->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 240, 1));
          $this->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 240, 1));
          $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 240, 1));
        }elseif($this->isMinerClass()){
        	if(!isset($this->armorEffects[$this->getName()]["Miner"])){
                $this->armorEffects[$this->getName()]["Miner"] = $this;
            $this->sendMessage(" \n§aActivated Class §l§7--> §7Miner\n ");    
            }
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 240, 1));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 240, 2));
            $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 240, 1));
            if($this->getY() < 40){
                $this->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 240, 1));
            }
        }else{
        	if(isset($this->armorEffects[$this->getName()]["Bard"])){
                $this->sendMessage(" \n§cDeactivated Class §l§7--> §6Bard\n ");
        		$this->removeEffect(Effect::SPEED);
                $this->removeEffect(Effect::REGENERATION);
        		unset($this->armorEffects[$this->getName()]["Bard"]);
        	}
        	if(isset($this->armorEffects[$this->getName()]["Archer"])){
                $this->sendMessage(" \n§cDeactivated Class §l§7--> §dArcher\n ");
        		$this->removeEffect(Effect::SPEED);
                $this->removeEffect(Effect::REGENERATION);
                $this->removeEffect(Effect::FIRE_RESISTANCE);
        		unset($this->armorEffects[$this->getName()]["Archer"]);
            }
            if(isset($this->armorEffects[$this->getName()]["Rogue"])){
                $this->sendMessage(" \n§cDeactivated Class §l§7--> §9Rogue\n ");
        		$this->removeEffect(Effect::SPEED);
                $this->removeEffect(Effect::REGENERATION);
                $this->removeEffect(Effect::FIRE_RESISTANCE);
        		unset($this->armorEffects[$this->getName()]["Rogue"]);
        	}
        	if(isset($this->armorEffects[$this->getName()]["Miner"])){
                $this->sendMessage(" \n§cDeactivated Class §l§7--> §7Miner\n ");
                $this->removeEffect(Effect::HASTE);
                $this->removeEffect(Effect::NIGHT_VISION);
                $this->removeEffect(Effect::FIRE_RESISTANCE);
                unset($this->armorEffects[$this->getName()]["Miner"]);
            }
        }
    }

    /**
	 * @return void
	 */
	public function changeWorld() : void {
        $levelName = Loader::getDefaultConfig("LevelManager")["levelEndName"];
        if(!Loader::getInstance()->getServer()->isLevelGenerated($levelName)){
            $this->sendMessage(TE::RED.$levelName." does not exist, you must talk to the developer or owner to fix this!");
            return;
        }
        if(!Loader::getInstance()->getServer()->isLevelLoaded($levelName)){
            Loader::getInstance()->getServer()->loadLevel($levelName);
        }
        if($this->getLevel()->getFolderName() === Loader::getInstance()->getServer()->getDefaultLevel()->getFolderName()){
            $this->teleport(Loader::getInstance()->getServer()->getLevelByName($levelName)->getSafeSpawn());
        }elseif($this->getLevel()->getFolderName() === $levelName){
            if(!Factions::isSpawn($levelName)){
                $this->sendMessage(TE::RED."Oops there seems to be a bug you should talk to the developer");
                return;
            }
            $this->teleport(Factions::getSpawnLocation($levelName));
        }
    }

    /**
     * @param Item $item
     * @param bool $conditional
     */
    public function dropItem(Item $item, bool $conditional = false) : bool {
        if(!$conditional){
            parent::dropItem($item);
        }else{
            if(!$this->spawned||!$this->isAlive()){
                return false;
            }
            if($item->isNull()){
                $this->server->getLogger()->debug($this->getName()." attempted to drop a null item (".$item.")");
                return true;
            }
            $this->level->dropItem($this->add(0, 1.0, 0), $item);
            return true;
        }
        return true;
    }

    /**
     * @return void
     */
    public function addPermissionsPlayer() : void {
        $permission = Loader::getInstance()->getPermission($this);
		if($this->getRank() === "Guest"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
        if($this->getRank() === "Sr-Admin"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
        }
		if($this->getRank() === "Admin"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
		if($this->getRank() === "Jr-Admin"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
        if($this->getRank() === "Sr-Mod"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
		if($this->getRank() === "Mod"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
		if($this->getRank() === "Trainee"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
          if($this->getRank() === "Agua"){
            $file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
          if($this->getRank() === "Tierra"){
            $file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		} 
		if($this->getRank() === "Fuego"){
            $file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
        if($this->getRank() === "Eternal"){
            $file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
        if($this->getRank() === "Streamer"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
        if($this->getRank() === "Famous"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
	     }
         if($this->getRank() === "MiniYT"){
              $file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
         }
         if($this->getRank() === "Youtube"){
             $file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
          }
          if($this->getRank() === "Co-Founder"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
          }
          if($this->getRank() === "Founder"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
          }
          if($this->getRank() === "CEO"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
          }
          if($this->getRank() === "Creador"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
          }
		if($this->getRank() === "Partner"){
			$file = Loader::getConfiguration("permissions");
            foreach($file->get($this->getRank()) as $permissions){
                $permission->setPermission($permissions, true);
            }
		}
    }

    /**
     * @return void
     */
    public function removePermissionsPlayer() : void {
        unset(Loader::getInstance()->permission[$this->getName()]);
    }

    /**
     * @return void
     */
    public function showCoordinates() : void {
        $pk = new GameRulesChangedPacket();
        $pk->gameRules = ["showcoordinates" => [1, "true", true]];
        $this->dataPacket($pk);
	}

}

?>