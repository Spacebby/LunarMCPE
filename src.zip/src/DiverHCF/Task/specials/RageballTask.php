<?php

namespace DiverHCF\Task\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class RageballTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * StormBreakerTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setRageballTime(Loader::getDefaultConfig("Cooldowns")["Rageball"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun(Int $currentTick) : void {
        $player = $this->player;
        if(!$player->isOnline()){
            Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        if($player->getRageballTime() === 0){
            $player->setRageball(false);
            Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        }else{
            $player->setRageballTime($player->getRageballTime() - 1);
        }
    }
}

?>