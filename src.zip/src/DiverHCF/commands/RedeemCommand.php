<?php

namespace DiverHCF\commands;

use DiverHCF\Loader;
use DiverHCF\player\{Player, PlayerBase};

use DiverHCF\crate\CrateManager;
use DiverHCF\packages\PackageManager;
use DiverHCF\utils\Time;

use pocketmine\item\{Item, ItemIds};
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class RedeemCommand extends PluginCommand {
	
	/**
	 * ReclaimCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("redeem", Loader::getInstance());
		
		parent::setDescription("apoya a un creador");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */ 
		public function execute(CommandSender $sender, string $label, array $args): void
    {
        $senderName = $sender->getName();
        if (empty($args)) {
            $sender->sendMessage(
                TE::AQUA . "/{$label} TlooToonsMC " . TE::GRAY . "(apoyo a un creador)" . "\n" .
                TE::AQUA . "/{$label} XxSeba09xX " . TE::GRAY . "(apoyo a un creador)" . "\n" .
                TE::AQUA . "/{$label} El pepe " . TE::GRAY . "(apoyo a un creador)" . "\n" .
                TE::AQUA . "/{$label} Potaxio " . TE::GRAY . "(apoyo a un creador)" . "\n" .
                TE::AQUA . "/{$label} Space " . TE::GRAY . "(apoyo a un creador)" . "\n"
            );
            return;
        }
        switch ($args[0]) {
                case "Jhadiel":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					 #PackageManager::givePackage($sender, 3); 
					 #$this->partner($sender, 1);
                          CrateManager::giveKey($sender, "Partner", 4);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("boss_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                 case "Diaclox":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					#PackageManager::givePackage($sender, 3);
					#$this->partner($sender, 1);
                         CrateManager::giveKey($sender, "Partner", 4);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                case "Leon":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					#PackageManager::givePackage($sender, 3);
					CrateManager::giveKey($sender, "Partner", 4);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                case "Akyo":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					#PackageManager::givePackage($sender, 3);
					#$this->partner($sender, 1);
                         CrateManager::giveKey($sender, "Partner", 4);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                case "Space":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					#PackageManager::givePackage($sender, 3);
					#$this->partner($sender, 1);
                         CrateManager::giveKey($sender, "Koth", 1);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                case "qpro":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					#PackageManager::givePackage($sender, 3);
					#$this->partner($sender, 1);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                case "..":
                if($sender->hasPermission("public.redeem")){
			if($sender->getTimeRedeemRemaining() < time()){
				try {
					$sender->resetRedeemTime();

					#PackageManager::givePackage($sender, 3);
					#$this->partner($sender, 1);
                    

					Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_redeem_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
			}else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeRedeemRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
           break;
                      
}

        }
}
?>