<?php

namespace DiverHCF\vkit;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use DiverHCF\item\Items;

use pocketmine\utils\{Config, TextFormat as TE};

class vKitBackup {

    /**
     * @return void
     */
    public static function initAll() : void {
        $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."vkits.yml", Config::YAML);
        foreach($file->getAll() as $name => $values){
            self::init($name);
        }
    }

    /**
     * @return void
     */
    public static function saveAll() : void {
        foreach(vKitManager::getvKits() as $name => $values){
            self::save($name);
        }
    }

    /**
     * @param String $name
     * @return void
     */
    public static function init(String $name) : void {
        try {
            $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."vkits.yml", Config::YAML);
            $vkitData = $file->getAll()[$name];

            if(isset($vkitData["contents"])){
                foreach($vkitData["contents"] as $slot => $item){
                    $vkitData["contents"][$slot] = Items::itemDeserialize($item);
                }
            }
            if(isset($vkitData["armorContents"])){
                foreach($vkitData["armorContents"] as $slot => $item){
                    $vkitData["armorContents"][$slot] = Items::itemDeserialize($item);
                }
            }
            vKitManager::createvKit($vkitData);
        } catch (\Exception $exception) {
            Loader::getInstance()->getLogger()->error("Can't load vkit: ".$name);  
            Loader::getInstance()->getLogger()->error($exception->getMessage()); 
        }
    }

    /**
     * @param String $name
     * @return void
     */
    public static function save(String $name) : void {
        try {
            $crateData = [];

            $vkit = vKitManager::getvKit($name);
            $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."vkits.yml", Config::YAML);

            $vkitData["name"] = $vkit->getName();
            $vkitData["permission"] = $vkit->getPermission();
            $vkitData["nameFormat"] = $vkit->getNameFormat();

            foreach($vkit->getItems() as $slot => $item){
                $vkitData["contents"][$slot] = Items::itemSerialize($item);
            }
            foreach($vkit->getArmorItems() as $slot => $item){
                $vkitData["armorContents"][$slot] = Items::itemSerialize($item);
            }
            $file->set($vkit->getName(), $vkitData);
            $file->save();
        } catch (\Exception $exception){
            Loader::getInstance()->getLogger()->error("Can't save vkit: ".$name);
            Loader::getInstance()->getLogger()->error($exception->getMessage());
        }
    }
}

?>