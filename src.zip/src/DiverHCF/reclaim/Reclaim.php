<?php

namespace DiverHCF\reclaim;

class Reclaim {

    /** @var String */
    protected $name;

    /** @var Array[] */
    protected $items;

    /**
     * Reclaim Constructor.
     * @param String $name
     * @param Array $items
     */
    public function __construct(String $name, Array $items){
        $this->name = $name;
        $this->items = $items;
    }

    /**
	 * @return String
	 */
	public function getName() : String {
		return $this->name;
	}

	/**
	 * @param String $name
	 */
	public function setName(String $name){
		$this->name = $name;
	}
	
	/**
	 * @return Array[]
	 */
	public function getItems() : Array {
		return $this->items;
	}

	/**
	 * @param Array $items
	 */
	public function setItems(Array $items){
		$this->items = $items;
	}
}

?>