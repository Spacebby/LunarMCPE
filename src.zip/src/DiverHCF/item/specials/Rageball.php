<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\CompoundTag;

class Rageball extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Resistance Constructor.
	 */
	public function __construct(){
		parent::__construct(self::EGG, TE::BLUE.TE::BOLD."Ball Of Rage", [TE::RESET.TE::GRAY."Can get Resistance 3 and\nStrength 2 for yourself"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1)));
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 16;
    }
}

?>