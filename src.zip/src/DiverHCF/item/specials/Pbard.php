<?php

namespace DiverHCF\item\specials;

use DiverHCF\Loader;
use DiverHCF\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\CompoundTag;

class Pbard extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Strength Constructor.
	 */
	public function __construct(){
		parent::__construct(self::BLAZE_ROD, TE::BLUE.TE::BOLD."Magic Stick", [TE::RESET.TE::GRAY."Can get Resistance 3\nand Strength 2 and Regeneration 3 for yourself"]);
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM_ITEM));
        $this->addEnchantment(new EnchantmentInstance(new Enchantment(255, "", Enchantment::RARITY_COMMON, Enchantment::SLOT_ALL, Enchantment::SLOT_NONE, 1)));
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>