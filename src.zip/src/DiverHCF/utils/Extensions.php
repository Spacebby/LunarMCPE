<?php

namespace DiverHCF\utils;


use DiverHCF\kit\KitMenu;
use DiverHCF\KOTH\KOTHManager;
use DiverHCF\level\LevelManager;
use DiverHCF\Loader;
use DiverHCF\player\Player;

class Extensions {
    public static function getLevelManager(): LevelManager {
        return new LevelManager(Loader::getInstance());
    }

    public static function getKitManager() : KitMenu {
        return new KitMenu();
    }
}