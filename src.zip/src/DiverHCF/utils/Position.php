<?php

namespace DiverHCF\utils;

use DiverHCF\Loader;
use DiverHCF\faction\Faction;
use DiverHCF\player\Player;

use DiverHCF\utils\{Tower, Translator};

use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\item\{Item, ItemIds};

use pocketmine\network\mcpe\protocol\BlockActorDataPacket;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;

class Position {

    /** @var Array[] */
    public static $cache = [];

    /**
     * @param Player $player
     * @param Int $id
     */
    public static function getPosition(Player $player, Int $id){
        if(self::isPosition($player, $id)){
            return self::$cache[$player->getName()]["position".$id];
        }
    }

    /**
     * @param Player $player
     * @param Vector3 $position
     * @param Int $id
     */
    public static function setPosition(Player $player, Vector3 $position, Int $id) : void {
        self::$cache[$player->getName()]["position".$id] = Translator::vector3ToArray($position);
    }

    /**
     * @param Player $player
     * @param Int $id
     * @return bool 
     */
    public static function isPosition(Player $player, Int $id) : bool {
        if(isset(self::$cache[$player->getName()]["position".$id][0], self::$cache[$player->getName()]["position".$id][1], self::$cache[$player->getName()]["position".$id][2])){
            return true;
        }else{
            return false;
        }
    }

    /**
     * @param Player $player
     * @param Int $position
     * @param bool $tool
     * @return void
     */
    public static function deletePosition(Player $player, Int $id, bool $tool = false) : void {
        if(self::isPosition($player, $id)){
            unset(self::$cache[$player->getName()]["position".$id]);
            if($tool){
                if($player->isOpInteract()) $player->setOpInteract(false);
                if($player->isInteract()) $player->setInteract(false);
                $player->removeTool();
            }
        }   
        if($tool){
            if($player->isOpInteract()) $player->setOpInteract(false);
            if($player->isInteract()) $player->setInteract(false);
            $player->removeTool();
        }
    }
}

?>